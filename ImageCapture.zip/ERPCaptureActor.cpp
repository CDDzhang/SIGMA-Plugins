#include "ERPCaptureActor.h"

#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Misc/ScopedSlowTask.h"
#include "Misc/DateTime.h"
#include "HAL/FileManager.h"
#include "RenderingThread.h"
#include "UObject/ConstructorHelpers.h"
#include "UObject/UnrealType.h"
#include "GameFramework/PlayerController.h"
#include "Framework/Application/SlateApplication.h"

#if WITH_EDITOR
#include "Editor.h"
#endif

// ==================== 构造 ====================

AERPCaptureActor::AERPCaptureActor()
{
    // 不需要 Tick，所有捕获通过同步函数调用
    PrimaryActorTick.bCanEverTick = false;

    // Root：用 Icon mesh 作为 root，简化 transform 链
    Icon = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Icon"));
    SetRootComponent(Icon);

    // 给 Icon 一个默认可见的 mesh
    static ConstructorHelpers::FObjectFinder<UStaticMesh> SphereMeshFinder(
        TEXT("/Engine/BasicShapes/Sphere"));
    if (SphereMeshFinder.Succeeded())
    {
        Icon->SetStaticMesh(SphereMeshFinder.Object);
        Icon->SetWorldScale3D(FVector(0.2f));
    }
    Icon->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    Icon->SetHiddenInGame(true);
    Icon->SetCastShadow(false);
    Icon->SetOwnerNoSee(true);

    // 捕获组件：挂在 Icon 下面
    CaptureComponent = CreateDefaultSubobject<UERPCaptureComponent>(TEXT("CaptureComponent"));
    CaptureComponent->SetupAttachment(Icon);

}

void AERPCaptureActor::BeginPlay()
{
    Super::BeginPlay();
    
    // 让鼠标默认显示，不锁视口（方便点 Details 面板按钮）
    if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
    {
        PC->bShowMouseCursor = true;
        PC->SetInputMode(FInputModeGameAndUI());
    }
    
    if (bAutoRunOnBeginPlay)
    {
        // 延迟一帧再跑，让场景的所有初始化（光照、世界 streaming）完成
        FTimerHandle Handle;
        GetWorldTimerManager().SetTimer(Handle, [this]()
        {
            UE_LOG(LogTemp, Log, TEXT("AERPCaptureActor: Auto-running capture..."));

            // 自动加载 CSV（如果还没加载）
            if (Trajectory.Num() == 0 && !TrajectoryCSV.FilePath.IsEmpty())
            {
                LoadTrajectoryFromCSV();
            }

            RunCapture();

            if (bAutoQuitAfterRun)
            {
                UE_LOG(LogTemp, Log, TEXT("AERPCaptureActor: Auto-quitting PIE..."));
#if WITH_EDITOR
                if (GIsEditor && GEditor)
                {
                    GEditor->RequestEndPlayMap();
                    return;
                }
#endif
                // 非编辑器（独立游戏）下用 ConsoleCommand quit
                if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
                {
                    PC->ConsoleCommand(TEXT("quit"));
                }
            }
        }, 1.0f, /*bLoop=*/false);  // 延迟 1 秒，让场景稳定
    }
}

#if WITH_EDITOR
void AERPCaptureActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
    Super::PostEditChangeProperty(PropertyChangedEvent);

    const FName PropName = PropertyChangedEvent.GetPropertyName();
    if (PropName == GET_MEMBER_NAME_CHECKED(AERPCaptureActor, TrajectoryCSV))
    {
        // 修改 CSV 路径后清空旧轨迹，提示重新加载
        ClearTrajectory();
    }
}
#endif

// ==================== CSV 加载 ====================

int32 AERPCaptureActor::LoadTrajectoryFromCSV()
{
    Trajectory.Empty();
    LoadedFrameCount = 0;



    if (TrajectoryCSV.FilePath.IsEmpty())
    {
        UE_LOG(LogTemp, Warning,
            TEXT("AERPCaptureActor [%s]: TrajectoryCSV path is empty"), *GetName());
        return 0;
    }

    // 支持相对 ProjectDir 的路径
    FString FullPath = TrajectoryCSV.FilePath;
    if (FPaths::IsRelative(FullPath))
    {
        FullPath = FPaths::Combine(FPaths::ProjectDir(), FullPath);
    }

    if (!FPaths::FileExists(FullPath))
    {
        UE_LOG(LogTemp, Error,
            TEXT("AERPCaptureActor [%s]: CSV not found: %s"), *GetName(), *FullPath);
        return 0;
    }

    TArray<FString> Lines;
    if (!FFileHelper::LoadFileToStringArray(Lines, *FullPath))
    {
        UE_LOG(LogTemp, Error,
            TEXT("AERPCaptureActor [%s]: Failed to read CSV: %s"), *GetName(), *FullPath);
        return 0;
    }

    // 处理可能的 UTF-8 BOM（FFileHelper 在某些路径下不会自动剥）
    if (Lines.Num() > 0 && !Lines[0].IsEmpty() && Lines[0][0] == TCHAR(0xFEFF))
    {
        Lines[0].RemoveAt(0, 1, EAllowShrinking::No);
    }

    int32 LineNum = 0;
    int32 SkippedLines = 0;
    for (const FString& Line : Lines)
    {
        ++LineNum;
        FString Trimmed = Line.TrimStartAndEnd();

        // 跳过空行和注释
        if (Trimmed.IsEmpty() || Trimmed.StartsWith(TEXT("#"))) continue;
        // 首列不是数字时跳过表头行
        if (!Trimmed.IsEmpty() && !FChar::IsDigit(Trimmed[0]) && Trimmed[0] != TCHAR('-'))
        {
            UE_LOG(LogTemp, Verbose,
                TEXT("AERPCaptureActor: Skipping header line %d: %s"), LineNum, *Trimmed);
            continue;
        }

        FERPTrajectoryFrame Frame;
        if (!ParseCSVLine(Trimmed, Frame))
        {
            UE_LOG(LogTemp, Warning,
                TEXT("AERPCaptureActor [%s]: CSV line %d malformed, skipped: %s"),
                *GetName(), LineNum, *Trimmed);
            ++SkippedLines;
            continue;
        }

        Trajectory.Add(Frame);
    }

    LoadedFrameCount = Trajectory.Num();
    UE_LOG(LogTemp, Log,
        TEXT("AERPCaptureActor [%s]: Loaded %d frames from %s (skipped %d malformed lines)"),
        *GetName(), LoadedFrameCount, *FullPath, SkippedLines);

    return LoadedFrameCount;
}

bool AERPCaptureActor::ParseCSVLine(const FString& Line, FERPTrajectoryFrame& OutFrame) const
{
    TArray<FString> Tokens;
    Line.ParseIntoArray(Tokens, TEXT(","), /*InCullEmpty=*/false);

    if (Tokens.Num() < 8) return false;

    OutFrame.FrameId = FCString::Atoi(*Tokens[0].TrimStartAndEnd());

    const float X  = FCString::Atof(*Tokens[1].TrimStartAndEnd());
    const float Y  = FCString::Atof(*Tokens[2].TrimStartAndEnd());
    const float Z  = FCString::Atof(*Tokens[3].TrimStartAndEnd());
    const float QX = FCString::Atof(*Tokens[4].TrimStartAndEnd());
    const float QY = FCString::Atof(*Tokens[5].TrimStartAndEnd());
    const float QZ = FCString::Atof(*Tokens[6].TrimStartAndEnd());
    const float QW = FCString::Atof(*Tokens[7].TrimStartAndEnd());

    if (bConvertFromROS)
    {
        // ROS (右手, m, X前 Y左 Z上)  →  UE (左手, cm, X前 Y右 Z上)
        OutFrame.Location = FVector(X * 100.0f, -Y * 100.0f, Z * 100.0f);
        OutFrame.Rotation = FQuat(-QX, QY, -QZ, QW);
    }
    else
    {
        OutFrame.Location = FVector(X, Y, Z);
        OutFrame.Rotation = FQuat(QX, QY, QZ, QW);
    }
    OutFrame.Rotation.Normalize();

    return true;
}

// ==================== 主捕获循环 ====================

void AERPCaptureActor::RunCapture()
{
    if (Trajectory.Num() == 0)
    {
        UE_LOG(LogTemp, Warning,
            TEXT("AERPCaptureActor [%s]: Trajectory empty. Call LoadTrajectoryFromCSV first."),
            *GetName());
        return;
    }

    if (!CaptureComponent)
    {
        UE_LOG(LogTemp, Error,
            TEXT("AERPCaptureActor [%s]: CaptureComponent is null"), *GetName());
        return;
    }

    // 整批捕获使用同一个图像类型，从 CaptureComponent 当前的 ActiveImageType 读取
    const EImageType ActiveType = CaptureComponent->GetActiveImageType();

    UE_LOG(LogTemp, Log,
        TEXT("AERPCaptureActor [%s]: Starting capture of %d frames (type=%d) → %s"),
        *GetName(), Trajectory.Num(), (int32)ActiveType, *OutputSubFolder);

    // 准备输出目录
    const FString OutputDir = FPaths::Combine(FPaths::ProjectSavedDir(), OutputSubFolder);
    IFileManager::Get().MakeDirectory(*OutputDir, /*Tree=*/true);

    // 准备 metadata 文件
    FString MetadataPath;
    if (bWriteMetadata)
    {
        MetadataPath = FPaths::Combine(OutputDir, TEXT("metadata.csv"));
        WriteMetadataHeader(MetadataPath);
    }

    // 进度对话框
    FScopedSlowTask SlowTask(
        static_cast<float>(Trajectory.Num()),
        FText::FromString(TEXT("ERP Pano Capture")));
    SlowTask.MakeDialog(/*bShowCancelButton=*/true);

    int32 SuccessCount = 0;
    const double StartTime = FPlatformTime::Seconds();

    for (int32 i = 0; i < Trajectory.Num(); ++i)
    {
        if (SlowTask.ShouldCancel())
        {
            UE_LOG(LogTemp, Warning,
                TEXT("AERPCaptureActor [%s]: Cancelled by user at frame %d/%d"),
                *GetName(), i, Trajectory.Num());
            break;
        }

        // ★ 加这一行：检查 World 还有效
        UWorld* World = GetWorld();
        if (!World || World->bIsTearingDown)
        {
            UE_LOG(LogTemp, Warning,
                TEXT("AERPCaptureActor: World tearing down, abort at frame %d"), i);
            break;
        }

        // ★ 检查 Actor 自身还在世
        if (!IsValid(this) || IsActorBeingDestroyed())
        {
            UE_LOG(LogTemp, Warning, TEXT("AERPCaptureActor: Actor invalid, abort"));
            break;
        }

        const FERPTrajectoryFrame& Frame = Trajectory[i];

        SlowTask.EnterProgressFrame(1.0f, FText::FromString(
            FString::Printf(TEXT("Frame %d / %d  (id=%d)"),
                i + 1, Trajectory.Num(), Frame.FrameId)));

        // 1. 摆位姿
        ApplyPoseFromFrame(Frame);

        // 2. Warmup（默认 0 次，不执行）
        //    使用当前帧实际要采的 ActiveType，让 Lumen/TAA 基于目标后处理材质收敛
        for (int32 w = 0; w < WarmupFrames; ++w)
        {
            CaptureComponent->RequestCaptureImmediate(ActiveType);
            FlushRenderingCommands();
        }

        // 3. 实际捕获
        const FString SavedFile = CaptureFrame(Frame);

        // 4. 写 metadata
        if (bWriteMetadata && !SavedFile.IsEmpty())
        {
            WriteMetadataRow(MetadataPath, Frame, ActiveType, SavedFile);
        }

        if (!SavedFile.IsEmpty()) ++SuccessCount;
    }

    const double Elapsed = FPlatformTime::Seconds() - StartTime;
    UE_LOG(LogTemp, Log,
        TEXT("AERPCaptureActor [%s]: Capture finished: %d/%d frames in %.2f s (%.2f fps)"),
        *GetName(), SuccessCount, Trajectory.Num(),
        Elapsed, SuccessCount / FMath::Max(Elapsed, 0.001));
}

void AERPCaptureActor::ApplyPoseFromFrame(const FERPTrajectoryFrame& Frame)
{
    SetActorLocation(Frame.Location, /*bSweep=*/false, nullptr,
                     ETeleportType::TeleportPhysics);
    SetActorRotation(Frame.Rotation.Rotator(), ETeleportType::TeleportPhysics);

    // 强制立即把新 transform 推到渲染线程，
    // 否则同帧内的 CaptureScene 会用上一帧的 transform
    if (CaptureComponent)
    {
        CaptureComponent->MarkRenderTransformDirty();
        if (USceneCaptureComponentCube* Cube = CaptureComponent->GetCubeCapture())
        {
            Cube->MarkRenderTransformDirty();
        }
    }

    // 让渲染线程处理完 transform 更新再继续
    FlushRenderingCommands();
}

FString AERPCaptureActor::CaptureFrame(const FERPTrajectoryFrame& Frame)
{
    if (!CaptureComponent) return FString();

    const EImageType Type = CaptureComponent->GetActiveImageType();
    const FString FileName = FormatFileName(Frame.FrameId, Type);
    const FString FullPath = FPaths::Combine(
        FPaths::ProjectSavedDir(), OutputSubFolder, FileName + TEXT(".png"));

    // 跳过已存在 — 不切材质、不 flush，纯路径检查
    if (bSkipExisting && FPaths::FileExists(FullPath))
    {
        UE_LOG(LogTemp, Verbose,
            TEXT("AERPCaptureActor: Skipping existing file %s"), *FullPath);
        return FullPath;  // 仍记录到 metadata
    }

    // 整批使用同一个 ActiveImageType，无需在每帧切换材质
    // SaveCurrentEquirectToDisk 内部会做 capture + unwrap + flush + 写盘
    return CaptureComponent->SaveCurrentEquirectToDisk(
        FileName, OutputSubFolder, /*bCaptureFirst=*/true);
}

// ==================== 测试入口 ====================

void AERPCaptureActor::CaptureCurrentPose()
{
    if (!CaptureComponent)
    {
        UE_LOG(LogTemp, Error, TEXT("CaptureComponent is null"));
        return;
    }

    FERPTrajectoryFrame Dummy;
    Dummy.FrameId = -1;

    const FString Saved = CaptureFrame(Dummy);

    UE_LOG(LogTemp, Log, TEXT("CaptureCurrentPose: %s"),
        Saved.IsEmpty() ? TEXT("FAILED") : *Saved);
}

void AERPCaptureActor::ClearTrajectory()
{
    Trajectory.Empty();
    LoadedFrameCount = 0;
}

// ==================== 文件名格式化 ====================

FString AERPCaptureActor::FormatFileName(int32 FrameId, EImageType Type) const
{
    FString Result = FileNamePattern;

    // {frame:06d}, {frame:04d}, {frame:08d} 等
    // 简化：只支持 06d / 04d / 08d 三种常见的，需要更多自己加
    Result.ReplaceInline(TEXT("{frame:06d}"), *FString::Printf(TEXT("%06d"), FrameId));
    Result.ReplaceInline(TEXT("{frame:04d}"), *FString::Printf(TEXT("%04d"), FrameId));
    Result.ReplaceInline(TEXT("{frame:08d}"), *FString::Printf(TEXT("%08d"), FrameId));
    Result.ReplaceInline(TEXT("{frame}"),     *FString::Printf(TEXT("%d"), FrameId));
    // {mode} 用 EImageType 的 int 值替换（下游对照 EImageType 枚举即可）
    Result.ReplaceInline(TEXT("{mode}"),      *FString::Printf(TEXT("%d"), (int32)Type));

    // FrameId 为负（CaptureCurrentPose 测试）时，加时间戳避免覆盖
    if (FrameId < 0)
    {
        Result = FString::Printf(TEXT("test_mode%d_%s"),
            (int32)Type,
            *FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S")));
    }

    return Result;
}

// ==================== Metadata ====================

void AERPCaptureActor::WriteMetadataHeader(const FString& MetadataPath)
{
    const FString Header = TEXT("frame_id,x,y,z,qx,qy,qz,qw,mode,file\n");
    FFileHelper::SaveStringToFile(Header, *MetadataPath,
        FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
}

void AERPCaptureActor::WriteMetadataRow(const FString& MetadataPath,
                                        const FERPTrajectoryFrame& Frame,
                                        EImageType Type,
                                        const FString& SavedFile)
{
    const FVector& L = Frame.Location;
    const FQuat&   Q = Frame.Rotation;

    const FString Row = FString::Printf(
        TEXT("%d,%.4f,%.4f,%.4f,%.6f,%.6f,%.6f,%.6f,%d,%s\n"),
        Frame.FrameId, L.X, L.Y, L.Z, Q.X, Q.Y, Q.Z, Q.W,
        (int32)Type, *FPaths::GetCleanFilename(SavedFile));

    // 追加模式
    FFileHelper::SaveStringToFile(Row, *MetadataPath,
        FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM,
        &IFileManager::Get(),
        FILEWRITE_Append);
}