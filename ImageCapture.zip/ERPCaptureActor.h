#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/StaticMeshComponent.h"
#include "ERPCaptureComponent.h"
#include "ERPCaptureActor.generated.h"

/**
 * 单帧轨迹数据：仅包含位姿
 * 图像类型由 CaptureComponent 的 ActiveImageType 统一决定
 */
USTRUCT(BlueprintType)
struct FERPTrajectoryFrame
{
    GENERATED_BODY()

    /** CSV 中该帧的 ID（用于文件命名，不要求连续） */
    UPROPERTY(BlueprintReadWrite, Category = "PanoCapture")
    int32 FrameId = 0;

    /** 世界坐标位置（UE 单位 cm） */
    UPROPERTY(BlueprintReadWrite, Category = "PanoCapture")
    FVector Location = FVector::ZeroVector;

    /** 世界坐标旋转（四元数） */
    UPROPERTY(BlueprintReadWrite, Category = "PanoCapture")
    FQuat Rotation = FQuat::Identity;
};

/**
 * 全景 ERP 捕获 Actor
 * 
 * 用法：
 *   1. 拖入场景
 *   2. 在 Details 面板设置 TrajectoryCSV 文件路径
 *   3. 在 CaptureComponent 的 PostProcess 分类下选择 ActiveImageType
 *      （RGB / DepthPlanar / OpticalFlow / NormalPlanar）
 *   4. 点击 "Load Trajectory From CSV" 按钮
 *   5. 点击 "Run Capture" 按钮开始批量捕获
 *      —— 整批使用同一种图像类型；要换类型，改 ActiveImageType 后再跑一轮
 * 
 * CSV 格式（每行一帧）：
 *   frame_id, x, y, z, qx, qy, qz, qw
 *   注释行以 # 开头，空行忽略
 *   图像类型在 CaptureComponent 的 ActiveImageType 上设置（采集前手动选择）
 */
UCLASS(BlueprintType, Blueprintable, ClassGroup=(PanoCapture),
       meta=(DisplayName="ERP Capture Actor"))
class OMNIFISHEYES_API AERPCaptureActor : public AActor
{
    GENERATED_BODY()

public:
    AERPCaptureActor();

    // ==================== 组件 ====================

    /** 编辑器可见的图标 mesh，运行时隐藏 */
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PanoCapture|Components")
    TObjectPtr<UStaticMeshComponent> Icon;

    /** 核心捕获组件 */
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PanoCapture|Components")
    TObjectPtr<UERPCaptureComponent> CaptureComponent;

    // ==================== 轨迹配置 ====================

    /** CSV 轨迹文件路径（绝对路径或相对 ProjectDir） */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Trajectory",
        meta = (FilePathFilter = "csv"))
    FFilePath TrajectoryCSV;

    /** 是否将 CSV 中的 ROS 坐标系（右手 m, X 前 Y 左 Z 上）转换为 UE 坐标系（左手 cm, X 前 Y 右 Z 上） */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Trajectory")
    bool bConvertFromROS = false;

    /** 已加载的轨迹（只读，用于查看） */
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PanoCapture|Trajectory",
        meta = (DisplayName = "Loaded Frame Count"))
    int32 LoadedFrameCount = 0;

    // ==================== 输出配置 ====================

    /** 输出子目录（相对 ProjectSavedDir） */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Output")
    FString OutputSubFolder = TEXT("ERPDataset");

    /** 文件名格式。{frame:06d} = 6位补零帧号，{frame} = 帧号，{mode} = 模式名 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Output")
    FString FileNamePattern = TEXT("{frame:06d}_{mode}");

    /** 已存在的同名文件是否跳过（方便断点续跑） */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Output")
    bool bSkipExisting = false;

    /** 是否同时输出 metadata.csv（记录每帧实际位姿，方便下游对齐） */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Output")
    bool bWriteMetadata = true;

    // ==================== 时序配置 ====================

    /**
     * 切换到新位姿后，等待多少帧让渲染稳定。
     * 对"瞬移采样"模式（关掉 TAA/Lumen），通常设为 0。
     * 仅在以下情况需要 > 0：
     *   - 保留 Lumen 或 TAA：5~10 帧
     *   - 场景有动态物体（粒子、布料）：2~3 帧
     *   - 关卡刚加载，World Partition 还在 streaming：10~30 帧
     */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Timing",
        meta = (ClampMin = "0", ClampMax = "60"))
    int32 WarmupFrames = 0;

    // ==================== PIE 自动启动 ====================

    /**
     * 是否在 PIE 启动时自动开始 RunCapture。
     * 启用后：配置好 CSV → 点 Play → 自动加载 + 自动跑 + 自动停。
     */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Run",
        meta = (DisplayName = "Auto Run On Begin Play"))
    bool bAutoRunOnBeginPlay = false;

    /**
     * 自动跑结束后是否自动退出 PIE。
     * 仅在 bAutoRunOnBeginPlay = true 时有效。
     */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Run",
        meta = (DisplayName = "Auto Quit PIE After Run"))
    bool bAutoQuitAfterRun = false;

    // ==================== 蓝图入口 ====================

    /** 编辑器按钮：加载 CSV 轨迹文件（结果通过 LoadedFrameCount 字段查看） */
    UFUNCTION(BlueprintCallable, CallInEditor, Category = "PanoCapture",
        meta = (DisplayName = "1. Load Trajectory From CSV"))
    void LoadTrajectoryFromCSV_Button() { LoadTrajectoryFromCSV(); }

    /** 加载 CSV 轨迹文件，返回成功加载的帧数（蓝图可调用以拿到帧数） */
    UFUNCTION(BlueprintCallable, Category = "PanoCapture")
    int32 LoadTrajectoryFromCSV();

    /** 启动批量捕获（同步执行，会阻塞 GameThread 直到完成） */
    UFUNCTION(BlueprintCallable, CallInEditor, Category = "PanoCapture",
        meta = (DisplayName = "2. Run Capture"))
    void RunCapture();

    /** 测试：拍当前位姿一帧（用 CaptureComponent 的 ActiveImageType），不走轨迹 */
    UFUNCTION(BlueprintCallable, CallInEditor, Category = "PanoCapture|Debug",
        meta = (DisplayName = "Capture Current Pose (Test)"))
    void CaptureCurrentPose();

    /** 清空已加载的轨迹 */
    UFUNCTION(BlueprintCallable, CallInEditor, Category = "PanoCapture|Debug",
        meta = (DisplayName = "Clear Trajectory"))
    void ClearTrajectory();

protected:
    virtual void BeginPlay() override;

#if WITH_EDITOR
    virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

private:
    /** 已加载的轨迹数据 */
    UPROPERTY(Transient)
    TArray<FERPTrajectoryFrame> Trajectory;

    /** 应用一帧位姿到 Actor */
    void ApplyPoseFromFrame(const FERPTrajectoryFrame& Frame);

    /** 捕获一帧（使用 CaptureComponent 当前的 ActiveImageType），返回保存的文件路径，失败返回空字符串 */
    FString CaptureFrame(const FERPTrajectoryFrame& Frame);

    /** 文件名格式化（基于当前 ActiveImageType 的 int 值） */
    FString FormatFileName(int32 FrameId, EImageType Type) const;

    /** 解析单行 CSV，返回是否成功 */
    bool ParseCSVLine(const FString& Line, FERPTrajectoryFrame& OutFrame) const;

    /** 写 metadata.csv */
    void WriteMetadataHeader(const FString& MetadataPath);
    void WriteMetadataRow(const FString& MetadataPath, const FERPTrajectoryFrame& Frame,
                          EImageType Type, const FString& SavedFile);
};