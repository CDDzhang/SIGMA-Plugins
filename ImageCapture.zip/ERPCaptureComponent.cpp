#include "ERPCaptureComponent.h"

#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Misc/Paths.h"
#include "Misc/DateTime.h"
#include "Misc/FileHelper.h"
#include "ImageUtils.h"
#include "RenderingThread.h"
#include "UObject/ConstructorHelpers.h"
#include "Kismet/KismetRenderingLibrary.h"

UERPCaptureComponent::UERPCaptureComponent()
{
    // 不再需要 Tick，捕获由 PanoImageCapture 通过 AsyncTask 直接驱动
    PrimaryComponentTick.bCanEverTick = false;
    bAutoActivate = true;

    CubeCapture = CreateDefaultSubobject<USceneCaptureComponentCube>(TEXT("CubeCapture"));
    if (CubeCapture)
    {
        // Attachment 在构造函数里建立
        CubeCapture->SetupAttachment(this);
    }
}

void UERPCaptureComponent::OnRegister()
{
    Super::OnRegister();

    LoadDefaultMaterialsIfNeeded(); 

    if (!CubeCapture) return;

    // 创建/重建 CubeRT（始终使用当前属性值）
    if (CubeRenderTargetOverride)
    {
        CubeRT = CubeRenderTargetOverride;
    }
    else
    {
        CubeRT = NewObject<UTextureRenderTargetCube>(this, TEXT("CubeRT"));
        CubeRT->Init(CubeFaceSize, PF_FloatRGBA);
        CubeRT->UpdateResourceImmediate(true);
    }

    // 创建/重建 EquirectRT（始终使用当前属性值）
    EquirectRT = NewObject<UTextureRenderTarget2D>(this, TEXT("EquirectRT"));
    EquirectRT->InitCustomFormat(EquirectWidth, EquirectHeight, PF_B8G8R8A8, false);
    EquirectRT->TargetGamma = 2.2f;
    EquirectRT->UpdateResourceImmediate(true);
    CubeCapture->TextureTarget = CubeRT;
    CubeCapture->bCaptureRotation = bUseCubeCaptureRotation;

    CubeCapture->AttachToComponent(this, FAttachmentTransformRules::KeepRelativeTransform);


}

void UERPCaptureComponent::BeginPlay()
{
    Super::BeginPlay();
    EnsureInitialized();
}

void UERPCaptureComponent::EnsureInitialized()
{
    if (bInitialized || !CubeCapture) return;

    if (AActor* Owner = GetOwner())
        CubeCapture->HiddenActors.AddUnique(Owner);

    CreateUnwrapMID();

    CubeCapture->CaptureSource = ESceneCaptureSource::SCS_FinalColorLDR;
    CubeCapture->bCaptureEveryFrame = false;
    CubeCapture->bCaptureOnMovement = false;
    CubeCapture->bAlwaysPersistRenderingState = true;
    if (CubeCapture->TextureTarget != CubeRT)
        CubeCapture->TextureTarget = CubeRT;
    if (!CubeCapture->IsActive())
        CubeCapture->Activate();
    bCaptureActive = true;

    ApplyPostProcessMaterial(ActiveImageType);
    bInitialized = true;
}

/* CubeCapture->HiddenActors.Add(GetOwner());
    
    // ---- 展开材质校验 ----
    if (!UnwrapMaterial)
    {
        if (GEngine)
        {
            GEngine->AddOnScreenDebugMessage(-1, 30.f, FColor::Red,
                FString::Printf(TEXT("PanoCapture [%s]: UnwrapMaterial not assigned!"), *GetName()));
        }
    }

    // 创建展开用 MID
    CreateUnwrapMID();

    // 新 RT 还没有有效内容，下一次捕获需要重新 flush 一次
    bFirstCaptureCompleted = false;

    // ---- 配置 CubeCapture ----
    if (CubeCapture)
    {
        CubeCapture->CaptureSource = ESceneCaptureSource::SCS_FinalColorLDR;
        CubeCapture->bCaptureEveryFrame = false;
        CubeCapture->bCaptureOnMovement = false;
        CubeCapture->bAlwaysPersistRenderingState = true;

        if (CubeCapture->TextureTarget != CubeRT)
            CubeCapture->TextureTarget = CubeRT;

        if (!CubeCapture->IsActive())
            CubeCapture->Activate();

        bCaptureActive = true;
    }

    ApplyPostProcessMaterial(ActiveImageType);

    UE_LOG(LogTemp, Log,
        TEXT("PanoCapture [%s]: Ready — CubeRT=%s EquirectRT=%s UnwrapMat=%s"),
        *GetName(),
        CubeRT ? *CubeRT->GetName() : TEXT("NULL"),
        EquirectRT ? *EquirectRT->GetName() : TEXT("NULL"),
        UnwrapMaterial ? *UnwrapMaterial->GetName() : TEXT("NULL"));*/



// ==================== 立即捕获（GameThread 调用） ====================
void UERPCaptureComponent::RequestCaptureImmediate(EImageType type)
{
    check(IsInGameThread());
    EnsureInitialized();
    // 切换后处理材质
    SetActiveImageType(type);

    // 确保启用
    if (!bCaptureActive)
        SetCaptureEnabled(true);

    // 执行捕获+展开
    PerformCaptureAndUnwrap();
}

// ==================== 实际捕获+展开 ====================
FString UERPCaptureComponent::SaveCurrentEquirectToDisk(
    const FString& FileName, const FString& SubFolder, bool bCaptureFirst)
{
    if (!IsInGameThread())
    {
        UE_LOG(LogTemp, Error,
            TEXT("PanoCapture [%s]: SaveCurrentEquirectToDisk must be called on GameThread"),
            *GetName());
        return FString();
    }

    // 可选：先做一次捕获+展开
    if (bCaptureFirst)
    {
        EnsureInitialized();
        if (!bCaptureActive)
            SetCaptureEnabled(true);
        PerformCaptureAndUnwrap();
    }

    if (!EquirectRT)
    {
        UE_LOG(LogTemp, Error, TEXT("PanoCapture [%s]: EquirectRT is null"), *GetName());
        return FString();
    }

    FTextureRenderTargetResource* RTResource = EquirectRT->GameThread_GetRenderTargetResource();
    if (!RTResource)
    {
        UE_LOG(LogTemp, Error, TEXT("PanoCapture [%s]: RTResource is null"), *GetName());
        return FString();
    }

    // 确保 GPU 完成绘制
    FlushRenderingCommands();

    // ---- 关键：自己读像素 ----
    const int32 W = EquirectRT->SizeX;
    const int32 H = EquirectRT->SizeY;

    TArray<FColor> Pixels;
    Pixels.Empty(W * H);

    FReadSurfaceDataFlags ReadFlags(RCM_UNorm, CubeFace_MAX);
    ReadFlags.SetLinearToGamma(false);  // 已是 sRGB 色彩，不需要再转换

    if (!RTResource->ReadPixels(Pixels, ReadFlags))
    {
        UE_LOG(LogTemp, Error, TEXT("PanoCapture [%s]: ReadPixels failed"), *GetName());
        return FString();
    }

    // ---- 强制 Alpha = 255，避免 PNG 半透明问题 ----
    for (FColor& C : Pixels)
    {
        C.A = 255;
    }

    // ---- 用 FImageUtils 编码标准 PNG ----
    TArray64<uint8> PngData;
    FImageView ImgView(Pixels.GetData(), W, H, ERawImageFormat::BGRA8);
    if (!FImageUtils::CompressImage(PngData, TEXT("png"), ImgView, /*Quality=*/0))
    {
        UE_LOG(LogTemp, Error, TEXT("PanoCapture [%s]: PNG encode failed"), *GetName());
        return FString();
    }

    // ---- 组装路径并写盘 ----
    const FString FinalName = FileName.IsEmpty()
        ? FString::Printf(TEXT("equirect_%s"),
            *FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S")))
        : FileName;

    const FString FullDir  = FPaths::Combine(FPaths::ProjectSavedDir(), SubFolder);
    const FString FullPath = FPaths::Combine(FullDir, FinalName + TEXT(".png"));

    IFileManager::Get().MakeDirectory(*FullDir, /*Tree=*/true);

    if (!FFileHelper::SaveArrayToFile(PngData, *FullPath))
    {
        UE_LOG(LogTemp, Error, TEXT("PanoCapture [%s]: SaveArrayToFile failed: %s"),
            *GetName(), *FullPath);
        return FString();
    }

    UE_LOG(LogTemp, Log, TEXT("PanoCapture [%s]: Saved equirect (%dx%d, %lld bytes) to %s"),
        *GetName(), W, H, (long long)PngData.Num(), *FullPath);

    return FullPath;
}


void UERPCaptureComponent::PerformCaptureAndUnwrap()
{
    check(IsInGameThread());

    // 1. 拍摄 CubeMap
    if (CubeCapture && CubeCapture->IsActive() && CubeCapture->TextureTarget)
    {
        CubeCapture->CaptureScene();
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("PanoCapture [%s]: CaptureScene skipped"), *GetName());
        return;
    }

    // 等待 CubeMap 渲染完成，防止展开材质采样到未初始化数据
    // 只在首次捕获时 flush，后续帧 CubeRT 已有有效数据无需等待
    if (!bFirstCaptureCompleted)
    {
        FlushRenderingCommands();
        bFirstCaptureCompleted = true;
    }

    // 2. 展开 CubeMap → EquirectRT
    if (EquirectRT && UnwrapMID && CubeRT)
    {
        UWorld* World = GetWorld();
        if (World)
        {
            UnwrapMID->SetTextureParameterValue(FName("CubeTexture"), CubeRT);
            
            if(bUseCubeCaptureRotation)
            {
                UnwrapMID->SetVectorParameterValue(FName("Row0"), FLinearColor(1, 0, 0, 0));
                UnwrapMID->SetVectorParameterValue(FName("Row1"), FLinearColor(0, 1, 0, 0));
                UnwrapMID->SetVectorParameterValue(FName("Row2"), FLinearColor(0, 0, 1, 0));
            }

            UKismetRenderingLibrary::DrawMaterialToRenderTarget(World, EquirectRT, UnwrapMID);
        }
    }
    else
    {
        UE_LOG(LogTemp, Error,
            TEXT("PanoCapture [%s]: Unwrap skipped — UnwrapMID=%s CubeRT=%s EquirectRT=%s"),
            *GetName(),
            UnwrapMID ? TEXT("OK") : TEXT("NULL"),
            CubeRT ? TEXT("OK") : TEXT("NULL"),
            EquirectRT ? TEXT("OK") : TEXT("NULL"));
    }
}

// ==================== ICaptureComponentInterface ====================

void UERPCaptureComponent::SetActiveImageType(EImageType Type)
{
    if (Type >= EImageType::Count) return;
    if (ActiveImageType == Type && bCaptureActive)
    {
        // 相同类型，跳过避免重复设材质
        return;
    }
    ActiveImageType = Type;
    ApplyPostProcessMaterial(Type);

    UE_LOG(LogTemp, Log, TEXT("PanoCapture [%s]: ActiveImageType → %d"),
        *GetName(), (int32)Type);
}

void UERPCaptureComponent::SetCaptureEnabled(bool bEnabled)
{
    if (!CubeCapture || !CubeRT) return;

    if (bEnabled)
    {
        CubeCapture->TextureTarget = CubeRT;
        if (!CubeCapture->IsActive())
            CubeCapture->Activate();
    }
    else
    {
        if (CubeCapture->IsActive())
            CubeCapture->Deactivate();
    }
    bCaptureActive = bEnabled;
}

// ==================== 后处理材质 ====================

UMaterialInterface* UERPCaptureComponent::GetPostProcessMaterial(EImageType Type) const
{
    switch (Type)
    {
    case EImageType::RGB:          return PostProcessMaterial_RGB;
    case EImageType::DepthPlanar:  return PostProcessMaterial_Depth;
    case EImageType::OpticalFlow:  return PostProcessMaterial_OpticalFlow;
    case EImageType::NormalPlanar: return PostProcessMaterial_Normal;
    default: return nullptr;
    }
}

void UERPCaptureComponent::ApplyPostProcessMaterial(EImageType Type)
{
    if (!CubeCapture) return;

    CubeCapture->PostProcessSettings.WeightedBlendables.Array.Empty();

    UMaterialInterface* PPMaterial = GetPostProcessMaterial(Type);
    if (PPMaterial)
    {
        CubeCapture->PostProcessSettings.WeightedBlendables.Array.Add(
            FWeightedBlendable(1.0f, PPMaterial));
        CubeCapture->ShowFlags.SetPostProcessing(true);
    }
    else
    {
        CubeCapture->ShowFlags.SetPostProcessing(false);
    }
}

void UERPCaptureComponent::LoadDefaultMaterialsIfNeeded()
{
    // 展开材质
    if (!UnwrapMaterial)
    {
        UMaterialInterface* Loaded = LoadObject<UMaterialInterface>(
            /*Outer=*/nullptr,
            TEXT("/OmniFisheyes/PostProcessMaterials/M_PPCube2Equ.M_PPCube2Equ"));
        if (Loaded)
        {
            UnwrapMaterial = Loaded;
            UE_LOG(LogTemp, Log,
                TEXT("UERPCaptureComponent: Loaded default UnwrapMaterial"));
        }
        else
        {
            UE_LOG(LogTemp, Warning,
                TEXT("UERPCaptureComponent: Default UnwrapMaterial not found"));
        }
    }

    // Depth 材质
    if (!PostProcessMaterial_Depth)
    {
        UMaterialInterface* Loaded = LoadObject<UMaterialInterface>(
            nullptr,
            TEXT("/OmniFisheyes/PostProcessMaterials/M_PPDepth.M_PPDepth"));
       
        if (Loaded)
        {
            PostProcessMaterial_Depth = Loaded;
            UE_LOG(LogTemp, Log,
                TEXT("UERPCaptureComponent: Loaded default DepthMaterial"));
        }
        else
        {
            UE_LOG(LogTemp, Warning,
                TEXT("UERPCaptureComponent: Default DepthMaterial not found"));
        }
    }

    // Normal 材质
    if (!PostProcessMaterial_Normal)
    {
        UMaterialInterface* Loaded = LoadObject<UMaterialInterface>(
            nullptr,
            TEXT("/OmniFisheyes/PostProcessMaterials/M_PPNormalImage.M_PPNormalImage"));
       
        if (Loaded)
        {
            PostProcessMaterial_Normal = Loaded;
            UE_LOG(LogTemp, Log,
                TEXT("UERPCaptureComponent: Loaded default NormalMaterial"));
        }
        else
        {
            UE_LOG(LogTemp, Warning,
                TEXT("UERPCaptureComponent: Default NormalMaterial not found"));
        }
    }
    
    // OpticalFlow 材质
    if (!PostProcessMaterial_OpticalFlow)
    {
        UMaterialInterface* Loaded = LoadObject<UMaterialInterface>(
            nullptr,
            TEXT("/OmniFisheyes/PostProcessMaterials/M_PPOpticalFlowImage.M_PPOpticalFlowImage"));
       
        if (Loaded)
        {
            PostProcessMaterial_OpticalFlow = Loaded;
            UE_LOG(LogTemp, Log,
                TEXT("UERPCaptureComponent: Loaded default OpticalFlowMaterial"));
        }
        else
        {
            UE_LOG(LogTemp, Warning,
                TEXT("UERPCaptureComponent: Default OpticalFlowMaterial not found"));
        }
    }
}

// ==================== 展开材质 MID ====================

void UERPCaptureComponent::CreateUnwrapMID()
{
    if (!UnwrapMaterial)
    {
        UnwrapMID = nullptr;
        return;
    }

    UnwrapMID = UMaterialInstanceDynamic::Create(UnwrapMaterial, this);
    if (UnwrapMID && CubeRT)
    {
        UnwrapMID->SetTextureParameterValue(FName("CubeTexture"), CubeRT);
        UE_LOG(LogTemp, Log, TEXT("PanoCapture [%s]: Created UnwrapMID from %s"),
            *GetName(), *UnwrapMaterial->GetName());
    }
}

// ==================== 分辨率变更时重建 RT ====================

void UERPCaptureComponent::RebuildRenderTargets()
{
    // 重建 CubeRT
    if (!CubeRenderTargetOverride)
    {
        CubeRT = NewObject<UTextureRenderTargetCube>(this, TEXT("CubeRT"));
        CubeRT->Init(CubeFaceSize, PF_FloatRGBA);
        CubeRT->UpdateResourceImmediate(true);
    }

    // 重建 EquirectRT
    EquirectRT = NewObject<UTextureRenderTarget2D>(this, TEXT("EquirectRT"));
    EquirectRT->InitCustomFormat(EquirectWidth, EquirectHeight, PF_B8G8R8A8, false);
    EquirectRT->TargetGamma = 2.2f;
    EquirectRT->UpdateResourceImmediate(true);

    // 重新绑定 CubeCapture
    if (CubeCapture)
    {
        CubeCapture->TextureTarget = CubeRT;
    }

    // 重建展开材质（需要绑定新的 CubeRT）
    CreateUnwrapMID();

    UE_LOG(LogTemp, Log,
        TEXT("PanoCapture [%s]: Rebuilt RTs — Cube=%d  Equirect=%dx%d"),
        *GetName(), CubeFaceSize, EquirectWidth, EquirectHeight);
}

#if WITH_EDITOR
void UERPCaptureComponent::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
    Super::PostEditChangeProperty(PropertyChangedEvent);

    FName PropName = PropertyChangedEvent.GetPropertyName();
    if (PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, CubeFaceSize) ||
        PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, EquirectWidth) ||
        PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, EquirectHeight))
    {
        RebuildRenderTargets();
    }
    else if (PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, bUseCubeCaptureRotation))
    {
        if (CubeCapture)
        {
            CubeCapture->bCaptureRotation = bUseCubeCaptureRotation;
        }
    }
    else if (PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, ActiveImageType))
    {
        ApplyPostProcessMaterial(ActiveImageType);
    }
    else if (PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, PostProcessMaterial_RGB) ||
            PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, PostProcessMaterial_Depth) ||
            PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, PostProcessMaterial_OpticalFlow) ||
            PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, PostProcessMaterial_Normal))
    {
        ApplyPostProcessMaterial(ActiveImageType);
    }
    else if (PropName == GET_MEMBER_NAME_CHECKED(UERPCaptureComponent, UnwrapMaterial))
    {
        // 展开材质换了，重建 MID
        CreateUnwrapMID();
    }
}
#endif