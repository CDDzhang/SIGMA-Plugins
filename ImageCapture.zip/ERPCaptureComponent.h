#pragma once
#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "Components/SceneCaptureComponentCube.h"
#include "Engine/TextureRenderTargetCube.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "ICaptureComponent.h"
#include "HAL/PlatformProcess.h"
#include "ERPCaptureComponent.generated.h"

UCLASS(ClassGroup=(Camera), meta=(BlueprintSpawnableComponent), HideCategories=(Mobility))
class OMNIFISHEYES_API UERPCaptureComponent : public USceneComponent, public ICaptureComponentInterface
{
public:
	GENERATED_BODY()

public:
	UERPCaptureComponent();

	// ==================== CubeMap / Equirect 分辨率 ====================
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Output",
		meta = (ClampMin = "64", ClampMax = "4096"))
	int32 CubeFaceSize = 512;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Output",
		meta = (ClampMin = "64", ClampMax = "8192"))
	int32 EquirectWidth = 2048;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Output",
		meta = (ClampMin = "64", ClampMax = "4096"))
	int32 EquirectHeight = 1024;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Rotation",
		meta = (DisplayName = "Use Cube Capture Rotation"))
	bool bUseCubeCaptureRotation = true;

	// ==================== SceneCapture 后处理材质 ====================
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|PostProcess")
	TObjectPtr<UMaterialInterface> PostProcessMaterial_RGB;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|PostProcess")
	TObjectPtr<UMaterialInterface> PostProcessMaterial_Depth;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|PostProcess")
	TObjectPtr<UMaterialInterface> PostProcessMaterial_OpticalFlow;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|PostProcess")
	TObjectPtr<UMaterialInterface> PostProcessMaterial_Normal;

	/** 当前的图像输出类型。修改后立即切换后处理材质，后续捕获按此类型输出。 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|PostProcess",
		meta = (DisplayName = "Active Image Type"))
	EImageType ActiveImageType = EImageType::RGB;

	/** 蓝图：切换图像类型（线程安全检查 + 立即应用材质）。 */
	UFUNCTION(BlueprintCallable, Category = "PanoCapture",
		meta = (DisplayName = "Set Active Image Type"))
	void SetActiveImageTypeBP(EImageType Type) { SetActiveImageType(Type); }

	/** 蓝图：读取当前图像类型。 */
	UFUNCTION(BlueprintPure, Category = "PanoCapture",
		meta = (DisplayName = "Get Active Image Type"))
	EImageType GetActiveImageTypeBP() const { return ActiveImageType; }

	
	// ==================== Cube→Equirect 展开材质 ====================
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Unwrap",
		meta = (DisplayName = "Cube to Equirect Material"))
	TObjectPtr<UMaterialInterface> UnwrapMaterial;

	// ==================== 调试 ====================
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PanoCapture|Debug",
		meta = (DisplayName = "Cube Render Target (手动覆盖)"))
	TObjectPtr<UTextureRenderTargetCube> CubeRenderTargetOverride;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PanoCapture|Debug")
	TObjectPtr<USceneCaptureComponentCube> CubeCapture;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Transient, DuplicateTransient, Category = "PanoCapture|Debug")
	TObjectPtr<UTextureRenderTargetCube> CubeRT;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Transient, DuplicateTransient, Category = "PanoCapture|Debug")
	TObjectPtr<UTextureRenderTarget2D> EquirectRT;

	UFUNCTION(BlueprintCallable, Category = "PanoCapture|Debug",
		meta = (DisplayName = "Save Current Equirect To Disk"))
	FString SaveCurrentEquirectToDisk(
		const FString& FileName = TEXT(""),
		const FString& SubFolder = TEXT("PanoCaptures"),
		bool bCaptureFirst = true);

	// ==================== ICaptureComponentInterface ====================
	virtual void SetActiveImageType(EImageType Type) override;
	virtual EImageType GetActiveImageType() const override { return ActiveImageType; }
	virtual void SetCaptureEnabled(bool bEnabled) override;
	virtual bool IsCaptureEnabled() const override { return bCaptureActive; }
	virtual UTextureRenderTarget2D* GetReadbackRenderTarget() const override { return EquirectRT; }

	// ==================== PanoImageCapture 专用 ====================
	USceneCaptureComponentCube* GetCubeCapture() const { return CubeCapture; }
	UTextureRenderTargetCube* GetCubeRenderTarget() const { return CubeRT; }

	/**
	* 在 GameThread 上立即执行捕获+展开。
	* 调用者必须确保在 GameThread 上调用。
	* 执行完毕后 EquirectRT 的渲染命令已入队（GPU 尚未完成）。
	*/
	UFUNCTION(BlueprintCallable, Category = "PanoCapture",
	meta = (DisplayName = "Request Capture Immediate (Use Active Type)"))
	void RequestCaptureImmediateActive() { RequestCaptureImmediate(ActiveImageType); }
	
	void RequestCaptureImmediate(EImageType type);

protected:
	virtual void BeginPlay() override;
	virtual void OnRegister() override;
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

private:
	UPROPERTY(Transient, DuplicateTransient)
	TObjectPtr<UMaterialInstanceDynamic> UnwrapMID;


	bool bCaptureActive = false;
	bool bFirstCaptureCompleted = false;

	/** 重建 CubeRT / EquirectRT（分辨率变更时调用） */
	void RebuildRenderTargets();

	void PerformCaptureAndUnwrap();

	/** 切换 SceneCapture 后处理材质 */
	void ApplyPostProcessMaterial(EImageType Type);
	UMaterialInterface* GetPostProcessMaterial(EImageType Type) const;

	void LoadDefaultMaterialsIfNeeded();

	/** 创建展开用的 MID */
	void CreateUnwrapMID();

	bool bInitialized = false;
	void EnsureInitialized();
};
