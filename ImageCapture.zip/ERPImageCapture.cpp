// PanoImageCapture.cpp

#include "ERPImageCapture.h"
#include "TextureResource.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Async/Async.h"
#include "Async/ParallelFor.h"
#include "ImageUtils.h"

ERPImageCapture::ERPImageCapture(UERPCaptureComponent* component,
                                   UGameViewportClient* viewport)
    : Component_(component), GameViewport_(viewport)
{
    check(Component_ && GameViewport_);
    // TODO: 使用GAMEVIEWPORT未来在NoDisplay模式下实现图像采集
}

ERPImageCapture::~ERPImageCapture() {}

void ERPImageCapture::GetImageSize(int& width, int& height) const
{
    width = 0; height = 0;
    if (!IsValid(Component_)) return;
    width  = Component_->EquirectWidth;
    height = Component_->EquirectHeight;
}

void ERPImageCapture::GetCameraPose(float out_pose[7]) const
{
    for (int i = 0; i < 7; ++i) out_pose[i] = 0.f;
    out_pose[3] = 1.f;  // 默认单位四元数 w=1
    if (!IsValid(Component_)) return;

    FTransform t = Component_->GetComponentTransform();
    FVector pos  = t.GetLocation();
    FQuat   rot  = t.GetRotation();
    out_pose[0] = pos.X; out_pose[1] = pos.Y; out_pose[2] = pos.Z;
    out_pose[3] = rot.W; out_pose[4] = rot.X; out_pose[5] = rot.Y; out_pose[6] = rot.Z;
}

// ==================== CaptureImage ====================
std::vector<uint8_t> ERPImageCapture::CaptureImage(
    EImageType type, bool compress, int& out_width, int& out_height)
{
    out_width  = 0;
    out_height = 0;

    if (IsShuttingDown()) return {};

    // 用 shared_ptr 持有，让任何线程的 lambda 都能安全持有
    auto result = std::make_shared<RenderResult>();
    CaptureAndReadback(type, result);

    if (IsShuttingDown()) return {};

    out_width  = result->width;
    out_height = result->height;
    if (result->width == 0 || result->height == 0)
        return {};
    
    if (compress)
    {
        TArray<uint8> compressed;
        FImageUtils::CompressImageArray(result->width, result->height,
                                        result->bmp, compressed);
        return std::vector<uint8_t>(compressed.GetData(),
                                    compressed.GetData() + compressed.Num());
    }
    else
    {
        // ... 这里保留你方案 A 的 ParallelFor BGR 转换 ...
        const int32 pixel_count = result->width * result->height;
        std::vector<uint8_t> out(pixel_count * 3);

        const FColor* RESTRICT src = result->bmp.GetData();
        uint8_t* RESTRICT dst = out.data();

        constexpr int32 ParallelThreshold = 256 * 256;
        if (pixel_count < ParallelThreshold)
        {
            for (int32 i = 0; i < pixel_count; ++i)
            {
                const FColor& c = src[i];
                dst[i*3+0] = c.B; dst[i*3+1] = c.G; dst[i*3+2] = c.R;
            }
        }
        else
        {
            const int32 width  = result->width;
            const int32 height = result->height;
            ParallelFor(height, [src, dst, width](int32 y)
            {
                const FColor* RESTRICT row_src = src + y * width;
                uint8_t* RESTRICT row_dst = dst + y * width * 3;
                for (int32 x = 0; x < width; ++x)
                {
                    const FColor& c = row_src[x];
                    row_dst[x*3+0] = c.B;
                    row_dst[x*3+1] = c.G;
                    row_dst[x*3+2] = c.R;
                }
            });
        }
        return out;
    }
}

// ==================== 合并后的捕获+回读 ====================
void ERPImageCapture::CaptureAndReadback(EImageType type, std::shared_ptr<RenderResult> result)
{
    if (IsShuttingDown()) return;

    auto wait_signal     = std::make_shared<msr::airlib::WorkerThreadSignal>();
    auto shutdown_flag   = ShuttingDownFlag_;        // 复制 shared_ptr，引用计数 +1
    TWeakObjectPtr<UERPCaptureComponent> weak_component(Component_);

    AsyncTask(ENamedThreads::GameThread,
        [type, result, wait_signal, shutdown_flag, weak_component]()
    {
        check(IsInGameThread());

        if (shutdown_flag->load())
        {
            wait_signal->signal();
            return;
        }

        // ★ 安全获取 UObject
        UERPCaptureComponent* component = weak_component.Get();
        if (!component)
        {
            UE_LOG(LogTemp, Warning,
                TEXT("PanoImageCapture: Component already collected, abort"));
            wait_signal->signal();
            return;
        }

        component->RequestCaptureImmediate(type);

        UTextureRenderTarget2D* rt = component->GetReadbackRenderTarget();
        if (!rt)
        {
            UE_LOG(LogTemp, Error, TEXT("PanoImageCapture: RenderTarget is null"));
            wait_signal->signal();
            return;
        }

        ENQUEUE_RENDER_COMMAND(PanoDirectReadback)
        ([result, wait_signal, rt, shutdown_flag](FRHICommandListImmediate& RHICmdList)
        {
            // 渲染线程上再检查一次关闭标志
            if (shutdown_flag->load())
            {
                wait_signal->signal();
                return;
            }

            FTextureRenderTargetResource* resource = rt->GetRenderTargetResource();
            if (!resource || !resource->GetRenderTargetTexture().IsValid())
            {
                UE_LOG(LogTemp, Error, TEXT("PanoImageCapture: RT resource invalid"));
                wait_signal->signal();
                return;
            }

            const FTexture2DRHIRef& tex = resource->GetRenderTargetTexture();
            FIntPoint size = resource->GetSizeXY();
            result->width  = size.X;
            result->height = size.Y;

            FReadSurfaceDataFlags flags(RCM_UNorm, CubeFace_MAX);
            flags.SetLinearToGamma(false);
            RHICmdList.ReadSurfaceData(tex, FIntRect(0, 0, size.X, size.Y),
                                       result->bmp, flags);

            wait_signal->signal();
        });
    });

    // 等待循环：超时/shutdown 都允许提前 break，此时不再有悬垂风险
    constexpr int MaxWaitIterations = 600;  // 600 * 5ms = 3s
    int iterations = 0;
    while (!wait_signal->waitFor(5))
    {
        if (IsShuttingDown() || ++iterations >= MaxWaitIterations)
        {
            UE_LOG(LogTemp, Warning,
                TEXT("PanoImageCapture::CaptureAndReadback: wait aborted "
                     "(shutting_down=%d, iterations=%d)"),
                IsShuttingDown() ? 1 : 0, iterations);
            break;
        }
    }
    //   result/wait_signal/shutdown_flag 都由 lambda 持有 shared_ptr;引用计数保证它们存活到任务真正结束，不会悬垂
}