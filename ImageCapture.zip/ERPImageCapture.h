#pragma once

#include "CoreMinimal.h"
#include "ICaptureComponent.h"
#include "ERPCaptureComponent.h"
#include "Engine/GameViewportClient.h"
#include "common/WorkerThread.hpp"
#include "common/ClockFactory.hpp"
#include <memory>
#include <vector>


class ERPImageCapture : public ImageCaptureInterface
{
public:
	ERPImageCapture(UERPCaptureComponent* component, UGameViewportClient* viewport);
	virtual ~ERPImageCapture();

	virtual std::vector<uint8_t> CaptureImage(EImageType type, bool compress,
											   int& out_width, int& out_height) override;
	virtual void GetImageSize(int& width, int& height) const override;
	virtual void GetCameraPose(float out_pose[7]) const override;

private:
	struct RenderResult
	{
		TArray<FColor> bmp;
		int width  = 0;
		int height = 0;
	};

	void CaptureAndReadback(EImageType type, std::shared_ptr<RenderResult> result);

	UERPCaptureComponent*  Component_;
	UGameViewportClient*   GameViewport_;
};