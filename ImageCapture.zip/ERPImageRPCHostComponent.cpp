// ERPImageRpcHostComponent.cpp

#include "ERPImageRpcHostComponent.h"
#include "Engine/Engine.h"
#include "Engine/GameViewportClient.h"

UERPImageRpcHostComponent::UERPImageRpcHostComponent()
{
    PrimaryComponentTick.bCanEverTick = false;
}

void UERPImageRpcHostComponent::BeginPlay()
{
    Super::BeginPlay();

    AActor* Owner = GetOwner();
    if (!Owner)
    {
        UE_LOG(LogTemp, Error, TEXT("ERPImageRpcHostComponent: No owning Actor"));
        return;
    }

    // 1. 找到同 Actor 上的 ERP 捕获组件
    UERPCaptureComponent* Cap = Owner->FindComponentByClass<UERPCaptureComponent>();
    if (!Cap)
    {
        UE_LOG(LogTemp, Warning,
            TEXT("ERPImageRpcHostComponent: No UERPCaptureComponent on [%s], RPC not started"),
            *Owner->GetName());
        return;
    }

    // 2. 拿到 GameViewport (ERPImageCapture 构造要)
    UGameViewportClient* Viewport = nullptr;
    if (UWorld* World = GetWorld())
    {
        Viewport = World->GetGameViewport();
    }
    if (!Viewport)
    {
        UE_LOG(LogTemp, Error,
            TEXT("ERPImageRpcHostComponent: No GameViewportClient available — "
                 "RPC server requires PIE/Standalone play to capture"));
        return;
    }

    // 3. 创建 ImageCapture 桥接对象
    ImageCapture_ = MakeShared<ERPImageCapture>(Cap, Viewport);

    // 4. 启动 RPC server
    RpcServer_ = MakeUnique<ERPImageRpcServer>(
        ImageCapture_.Get(),
        static_cast<uint16_t>(RpcPort));

    // 把当前 image type 注入给 server, 用于 getImageInfo / getImage 元数据
    RpcServer_->SetImageTypeHint(static_cast<int32_t>(Cap->GetActiveImageType()));

    RpcServer_->Start();

    UE_LOG(LogTemp, Log,
        TEXT("ERPImageRpcHostComponent: RPC on port %d — %dx%d — Type %d — Actor [%s]"),
        RpcPort, Cap->EquirectWidth, Cap->EquirectHeight,
        static_cast<int32>(Cap->GetActiveImageType()), *Owner->GetName());

    if (GEngine)
    {
        GEngine->AddOnScreenDebugMessage(-1, 10.f, FColor::Green,
            FString::Printf(TEXT("ERP Image RPC on port %d — %dx%d — Actor [%s]"),
                RpcPort, Cap->EquirectWidth, Cap->EquirectHeight, *Owner->GetName()));
    }
}

void UERPImageRpcHostComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    // 必须在 Super::EndPlay 之前完成 RPC 关闭!
    if (RpcServer_)
    {
        const double T0 = FPlatformTime::Seconds();
        UE_LOG(LogTemp, Log, TEXT("ERPImageRpcHostComponent: Shutting down RPC server..."));

        // Stop() 内部会:
        //   1) 置关闭标志
        //   2) Capture_->RequestShutdown() 让正在等待 GPU readback 的 handler 跳出
        //   3) server->stop() join 所有工作线程
        RpcServer_->Stop();
        RpcServer_.Reset();

        const double Elapsed = FPlatformTime::Seconds() - T0;
        UE_LOG(LogTemp, Log,
            TEXT("ERPImageRpcHostComponent: RPC server destroyed (%.3f ms)"),
            Elapsed * 1000.0);
    }

    // ImageCapture_ 的析构是安全的: 此时 RpcServer 已经 join 完所有线程,
    // 不会再有 lambda 在访问它持有的 Component_ / GameViewport_ 指针
    ImageCapture_.Reset();

    Super::EndPlay(EndPlayReason);
}