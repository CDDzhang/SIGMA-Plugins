#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ERPImageRpcServer.h"
#include "ERPImageCapture.h"
#include "ERPCaptureComponent.h"
#include "ERPImageRpcHostComponent.generated.h"

/**
 * 附加到 Actor (例如 AERPCaptureActor) 上,
 * 自动查找 UERPCaptureComponent 并启动图像 RPC 服务。
 *
 * 端口默认 41451 (沿用 AirSim 默认), Lidar 用的是 41452。
 *
 * 图像类型由 UERPCaptureComponent::ActiveImageType 控制,
 * RPC 端不暴露切换接口 — 在 UE 编辑器里选好类型再 PIE 即可。
 */
UCLASS(ClassGroup=(Sensor), meta=(BlueprintSpawnableComponent))
class OMNIFISHEYES_API UERPImageRpcHostComponent : public UActorComponent
{
	GENERATED_BODY()
 
public:
	UERPImageRpcHostComponent();
 
	/** RPC 监听端口 (默认 41451) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RPC")
	int32 RpcPort = 41451;
 
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
 
private:
	/** RPC server */
	TUniquePtr<ERPImageRpcServer> RpcServer_;
 
	/**
	 * 持有的 ImageCapture 实例。
	 * UERPCaptureComponent 本身不创建 ImageCaptureInterface 实例
	 * (它是 capture 的"数据源",不是"流程控制者"),
	 * 所以这里我们自己创建一个 ERPImageCapture 来桥接。
	 */
	TSharedPtr<ImageCaptureInterface> ImageCapture_;
};