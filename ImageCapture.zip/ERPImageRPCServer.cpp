#include "ERPImageRPCServer.h"
#include "HAL/PlatformTime.h"

ERPImageRpcServer::ERPImageRpcServer(ImageCaptureInterface* Capture, uint16_t Port)
    : Capture_(Capture), Port_(Port)
{
    try
    {
        Server_ = std::make_unique<rpc::server>(Port_);
        Server_->suppress_exceptions(true);
        BindMethods();
    }
    catch (const std::exception& e)
    {
        UE_LOG(LogTemp, Error,
            TEXT("ERPImageRpcServer: Failed to bind port %d — %hs"), Port_, e.what());
        Server_.reset();
    }
}

ERPImageRpcServer::~ERPImageRpcServer()
{
    Stop();
}

void ERPImageRpcServer::Start()
{
    if (!Server_)
    {
        UE_LOG(LogTemp, Error,
            TEXT("ERPImageRpcServer: Cannot start — server not constructed"));
        return;
    }
    if (bRunning.load(std::memory_order_acquire)) return;

    bShuttingDown.store(false, std::memory_order_release);
    bRunning.store(true, std::memory_order_release);
    // 4 个工作线程足够: 图像帧吞吐较低 (通常 < 30 FPS)
    Server_->async_run(4);
    UE_LOG(LogTemp, Log, TEXT("ERPImageRpcServer: Started on port %d"), Port_);
}

void ERPImageRpcServer::Stop()
{
    if (!bRunning.load(std::memory_order_acquire)) return;

    UE_LOG(LogTemp, Log, TEXT("ERPImageRpcServer: Stopping..."));

    // ① 置关闭标志
    bShuttingDown.store(true, std::memory_order_release);

    // ② 通知 capture 实现也开始关闭
    //    这样 ERPImageCapture 内部的 waitFor 循环会立即跳出,
    //    handler 里阻塞在 CaptureImage() 的调用会迅速返回空 vector
    {
        std::lock_guard<std::mutex> Lock(Mutex_);
        if (Capture_)
        {
            Capture_->RequestShutdown();
        }
        Capture_ = nullptr;
    }

    // ③ rpclib 自身停止 accept、关闭连接、join 所有工作线程
    if (Server_)
    {
        Server_->stop();
    }

    bRunning.store(false, std::memory_order_release);
    UE_LOG(LogTemp, Log, TEXT("ERPImageRpcServer: Stopped"));
}

// ─── 安全获取指针 ─────────────────────────────────────────────
ImageCaptureInterface* ERPImageRpcServer::GetCaptureSafe()
{
    std::lock_guard<std::mutex> Lock(Mutex_);
    if (bShuttingDown.load(std::memory_order_acquire)) return nullptr;
    return Capture_;
}

// ─── RPC 方法绑定 ────────────────────────────────────────────────
void ERPImageRpcServer::BindMethods()
{
    /* ─── ping ─── */
    Server_->bind("ping", [this]() -> bool
    {
        return !bShuttingDown.load(std::memory_order_acquire);
    });

    /* ─── getImageInfo ─── 返回 [width, height, image_type] */
    Server_->bind("getImageInfo", [this]() -> std::vector<int32_t>
    {
        std::lock_guard<std::mutex> Lock(Mutex_);
        if (bShuttingDown.load(std::memory_order_acquire) || !Capture_)
        {
            return { 0, 0, 0 };
        }

        int w = 0, h = 0;
        Capture_->GetImageSize(w, h);

        return { static_cast<int32_t>(w),
                 static_cast<int32_t>(h),
                 ImageTypeHint_.load() };
    });

    /* ─── getCameraPose ─── 返回 [x,y,z, qw,qx,qy,qz] */
    Server_->bind("getCameraPose", [this]() -> std::vector<float>
    {
        ImageCaptureInterface* Cap = GetCaptureSafe();
        if (!Cap) return { 0, 0, 0, 1, 0, 0, 0 };

        float pose[7] = { 0, 0, 0, 1, 0, 0, 0 };
        Cap->GetCameraPose(pose);
        return std::vector<float>(pose, pose + 7);
    });

    /* ─── getImage ─── 主接口: 抓一帧 PNG 压缩图像
     *  返回 tuple: (data, width, height, image_type, timestamp_ns)
     *    data        : std::vector<uint8_t>  PNG 字节流
     *    width       : int32_t
     *    height      : int32_t
     *    image_type  : int32_t  (EImageType 的整数值, 仅作元数据指示)
     *    timestamp_ns: int64_t  (FPlatformTime 时间戳,纳秒)
     */
    Server_->bind("getImage",
        [this]() -> std::tuple<std::vector<uint8_t>, int32_t, int32_t, int32_t, int64_t>
    {
        const int32_t type_hint = ImageTypeHint_.load();

        std::vector<uint8_t> empty;
        auto make_empty = [&]() {
            return std::make_tuple(empty, int32_t(0), int32_t(0),
                                   type_hint, int64_t(0));
        };

        ImageCaptureInterface* Cap = GetCaptureSafe();
        if (!Cap) return make_empty();

        int w = 0, h = 0;

        // ★ 关键: CaptureImage 内部自己切 GameThread / 等待 GPU readback,
        //         所以这里直接在 RPC 工作线程同步调用即可,不需要再包 GameThread。
        //         若关闭中,内部 wait 循环会跳出,返回空 vector。
        //
        // type 参数实际上被忽略 (capture 内部用的是 component 的 ActiveImageType),
        // 但接口要求传一个; 用 hint 值即可。compress=true 走 PNG 压缩。
        std::vector<uint8_t> data = Cap->CaptureImage(
            static_cast<EImageType>(type_hint), /*compress=*/true, w, h);

        if (bShuttingDown.load(std::memory_order_acquire) || data.empty())
        {
            return make_empty();
        }

        // 时间戳: 纳秒 (Unix-style 相对纪元不保证,仅用于客户端做相对时序对齐)
        const int64_t ts_ns = static_cast<int64_t>(
            FPlatformTime::ToSeconds64(FPlatformTime::Cycles64()) * 1e9);

        return std::make_tuple(std::move(data),
                               static_cast<int32_t>(w),
                               static_cast<int32_t>(h),
                               type_hint,
                               ts_ns);
    });
}