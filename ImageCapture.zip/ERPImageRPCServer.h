#pragma once

#include "CoreMinimal.h"
#include "ICaptureComponent.h"
#include <memory>
#include <atomic>
#include <mutex>

// ─── rpclib 包含前: 先隔离 UE 的宏污染 ───────────────────────
#pragma push_macro("check")
#pragma push_macro("verify")
#undef check
#undef verify
 
#include "rpc/server.h"
 
#pragma pop_macro("verify")
#pragma pop_macro("check")

/**
 * MsgPack-RPC 服务端 — 暴露 ERP 全景图像数据给 Python 客户端 (局域网)。
 *
 * 设计要点:
 * 1. bShuttingDown 原子标志 — handler 入口立即返回空
 * 2. Capture_ 指针通过 mutex 保护 — Stop() 时置 nullptr 并请求 capture 自身 shutdown
 * 3. 与 Lidar 不同: 不在 handler 里调 RunOnGameThreadSync,
 *    因为 ImageCaptureInterface::CaptureImage() 内部已自己切到 GameThread 等待
 * 4. Server_->stop() 自身 join 所有工作线程
 *
 * 图像类型 (RGB / Depth / Flow / Normal) 由 UE 编辑器侧
 * 通过 UERPCaptureComponent::ActiveImageType 设定, RPC 不提供切换接口。
 *
 * 暴露的 RPC 方法 (msgpack-rpc):
 *   ping()              -> bool                          连通性检测
 *   getImageInfo()      -> [w, h, image_type]            元数据 (3 ints)
 *   getCameraPose()     -> [x,y,z, qw,qx,qy,qz]          位姿 (7 floats)
 *   getImage()          -> (data, width, height,
 *                           image_type, timestamp_ns)    PNG 压缩后的图像帧
 */
class ERPImageRpcServer
{
public:
	/**
	 * @param Capture   实际的图像采集器,由 host component 创建并持有
	 * @param Port      RPC 监听端口,默认 41451 (沿用 AirSim 默认)
	 */
	ERPImageRpcServer(ImageCaptureInterface* Capture, uint16_t Port = 41451);
	~ERPImageRpcServer();
 
	void Start();
	void Stop();
	bool IsRunning() const { return bRunning.load(std::memory_order_acquire); }
 
	/** HostComponent 在 BeginPlay 时把当前 image type 注入,用于 getImageInfo 返回 */
	void SetImageTypeHint(int32_t TypeHint) { ImageTypeHint_.store(TypeHint); }
 
private:
	void BindMethods();
 
	/** 加锁取 Capture 指针;关闭中返回 nullptr */
	ImageCaptureInterface* GetCaptureSafe();
 
	mutable std::mutex             Mutex_;
	ImageCaptureInterface*         Capture_;       // 受 Mutex_ 保护
	std::unique_ptr<rpc::server>   Server_;
	uint16_t                       Port_;
	std::atomic<bool>              bRunning      { false };
	std::atomic<bool>              bShuttingDown { false };
	std::atomic<int32_t>           ImageTypeHint_{ 0 };  // EImageType 整数值
};