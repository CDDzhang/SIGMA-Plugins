#pragma once

#include "CoreMinimal.h"
#include "Engine/TextureRenderTarget2D.h"
#include <vector>
#include <cstdint>
#include <atomic>
#include <memory>

#include "ICaptureComponent.generated.h"

UENUM(BlueprintType)
enum class EImageType : uint8
{
	RGB          = 0,
	DepthPlanar  = 1,
	OpticalFlow  = 2,
	NormalPlanar = 3,
	Count        UMETA(Hidden)
};

UINTERFACE(MinimalAPI)
class UCaptureComponentInterface : public UInterface
{
	GENERATED_BODY()
};

class ICaptureComponentInterface
{
	GENERATED_BODY()

public:
	virtual void SetActiveImageType(EImageType Type) = 0;
	virtual EImageType GetActiveImageType() const = 0;
	virtual void SetCaptureEnabled(bool bEnabled) = 0;
	virtual bool IsCaptureEnabled() const = 0;
	virtual UTextureRenderTarget2D* GetReadbackRenderTarget() const = 0;
};


class ImageCaptureInterface
{
public:
	ImageCaptureInterface() : ShuttingDownFlag_(std::make_shared<std::atomic<bool>>(false)){}
	
	virtual ~ImageCaptureInterface() = default;

	/**
	 * 捕获一帧图像，返回 BGR uint8 字节
	 * 各实现走各自最优流程
	 */
	virtual std::vector<uint8_t> CaptureImage(EImageType type, bool compress,
											   int& out_width, int& out_height) = 0;

	/** 获取 RenderTarget 尺寸 */
	virtual void GetImageSize(int& width, int& height) const = 0;

	/** 获取位姿 [x,y,z, qw,qx,qy,qz] */
	virtual void GetCameraPose(float out_pose[7]) const = 0;

	/** 通知捕获实现开始关闭 — wait 循环应检查此标志提前退出 */
	void RequestShutdown() { ShuttingDownFlag_->store(true); }
	bool IsShuttingDown() const { return ShuttingDownFlag_->load(); }

protected:
	/** 共享所有权的关闭标志，子类可以传给异步任务安全持有 */
	std::shared_ptr<std::atomic<bool>> ShuttingDownFlag_;
};
