#pragma once

#include "CoreMinimal.h"
#include "ILidarComponent.generated.h"

/* ─── VLP-16模型 - 雷达配置结构体 ─── */
USTRUCT(BlueprintType)
struct FLidarConfig
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	int32 NumberOfChannels = 16;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	float VerticalFovUpperDeg = 10.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	float VerticalFovLowerDeg = -30.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	float PointsPerSecond = 100000.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	float HorizontalRotationFrequencyHz = 10.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	float HorizontalFovStartDeg = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	float HorizontalFovEndDeg = 359.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	float RangeMeters = 100.f;

	/** 射线检测使用的碰撞通道 (默认 Visibility) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	TEnumAsByte<ECollisionChannel> TraceChannel = ECC_Visibility;

	/**
	 * 点云输出频率 (Hz)。
	 * 多个 Tick 的射线结果会被积累, 达到 1/UpdateFrequencyHz 秒后
	 * 一次性输出完整帧, 与 AirSim FrequencyLimiter 行为一致。
	 * 默认 10Hz + 旋转 10Hz = 每次输出恰好一整圈 360°。
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar",
		meta = (ClampMin = "0.1", ClampMax = "100"))
	float UpdateFrequencyHz = 10.f;
};

/* ─── 雷达采集纯虚接口 ─── */
class ILidarComponent
{
public:
	virtual ~ILidarComponent() = default;

	/** 获取最近一帧的点云数据 (x,y,z 交错, 每点3个float) */
	virtual void GetLidarData(TArray<float>& OutPointCloud, int32& OutNumPoints) = 0;

	/** 获取传感器位姿: pos(3) + quat(4) = 7 floats */
	virtual void GetLidarPose(float OutPose[7]) = 0;

	/** 获取当前配置 */
	virtual FLidarConfig GetLidarConfig() const = 0;
};