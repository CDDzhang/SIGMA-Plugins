// LidarRpcHostComponent.cpp

#include "LidarRpcHostComponent.h"
#include "LidarSensorComponent.h"
#include "Engine/Engine.h"

ULidarRpcHostComponent::ULidarRpcHostComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void ULidarRpcHostComponent::BeginPlay()
{
	Super::BeginPlay();

	AActor* Owner = GetOwner();
	if (!Owner)
	{
		UE_LOG(LogTemp, Error, TEXT("LidarRpcHostComponent: No owning Actor"));
		return;
	}

	ULidarSensorComponent* LidarComp = Owner->FindComponentByClass<ULidarSensorComponent>();
	if (!LidarComp)
	{
		UE_LOG(LogTemp, Warning,
			TEXT("LidarRpcHostComponent: No LidarSensorComponent on [%s], RPC not started"),
			*Owner->GetName());
		return;
	}

	RpcServer_ = MakeUnique<LidarRpcServer>(
		static_cast<ILidarComponent*>(LidarComp),
		static_cast<uint16_t>(RpcPort));
	RpcServer_->Start();

	UE_LOG(LogTemp, Log,
		TEXT("LidarRpcHostComponent: RPC on port %d — %d ch — Actor [%s]"),
		RpcPort, LidarComp->Config.NumberOfChannels, *Owner->GetName());

	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 10.f, FColor::Cyan,
			FString::Printf(TEXT("Lidar RPC on port %d — %d ch — Actor [%s]"),
				RpcPort, LidarComp->Config.NumberOfChannels, *Owner->GetName()));
	}
}

void ULidarRpcHostComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	// 必须在 Super::EndPlay 之前完成 RPC 关闭！
	if (RpcServer_)
	{
		const double T0 = FPlatformTime::Seconds();
		UE_LOG(LogTemp, Log, TEXT("LidarRpcHostComponent: Shutting down RPC server..."));

		RpcServer_->Stop();   // 内部: 置标志 → 切断 Lidar → server::stop() join 线程
		RpcServer_.Reset();   // 销毁 server 对象

		const double Elapsed = FPlatformTime::Seconds() - T0;
		UE_LOG(LogTemp, Log,
			TEXT("LidarRpcHostComponent: RPC server destroyed (%.3f ms)"), Elapsed * 1000.0);
	}

	Super::EndPlay(EndPlayReason);
}