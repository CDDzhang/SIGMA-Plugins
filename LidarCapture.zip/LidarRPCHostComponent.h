#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ILidarComponent.h"
#include "LidarRpcServer.h"
#include "LidarRpcHostComponent.generated.h"

/**
 * 附加到 Actor 上, 自动查找 ULidarSensorComponent 并启动 RPC 服务。
 */
UCLASS(ClassGroup=(Sensor), meta=(BlueprintSpawnableComponent))
class OMNIFISHEYES_API ULidarRpcHostComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	ULidarRpcHostComponent();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RPC")
	int32 RpcPort = 41452;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	TUniquePtr<LidarRpcServer> RpcServer_;
};
