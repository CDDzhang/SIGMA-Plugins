// LidarRpcServer.cpp

#include "LidarRpcServer.h"
#include "Async/Async.h"
#include "HAL/PlatformProcess.h"

LidarRpcServer::LidarRpcServer(ILidarComponent* Lidar, uint16_t Port)
	: Lidar_(Lidar), Port_(Port)
{
	try
	{
		Server_ = std::make_unique<rpc::server>(Port_);
		Server_->suppress_exceptions(true);
		BindMethods();
	}
	catch (const std::exception& e)
	{
		UE_LOG(LogTemp, Error,
			TEXT("LidarRpcServer: Failed to bind port %d — %hs"), Port_, e.what());
		Server_.reset();
	}
}

LidarRpcServer::~LidarRpcServer()
{
	Stop();
}

void LidarRpcServer::Start()
{
	if (!Server_)
	{
		UE_LOG(LogTemp, Error, TEXT("LidarRpcServer: Cannot start — server not constructed"));
		return;
	}
	if (bRunning.load(std::memory_order_acquire)) return;

	bShuttingDown.store(false, std::memory_order_release);
	bRunning.store(true, std::memory_order_release);
	Server_->async_run();
	UE_LOG(LogTemp, Log, TEXT("LidarRpcServer: Started on port %d"), Port_);
}

void LidarRpcServer::Stop()
{
	if (!bRunning.load(std::memory_order_acquire)) return;

	UE_LOG(LogTemp, Log, TEXT("LidarRpcServer: Stopping..."));

	// ① 置关闭标志 — 所有正在进行的 RunOnGameThreadSync 立即结束等待
	bShuttingDown.store(true, std::memory_order_release);

	// ② 切断 Lidar 指针 — 即使 handler 还没看到 bShuttingDown 也不会触碰 UObject
	{
		std::lock_guard<std::mutex> Lock(LidarMutex_);
		Lidar_ = nullptr;
	}

	// ③ rpclib 自身会停止 accept、关闭连接、join 所有工作线程
	//    handler 此时若还在 RunOnGameThreadSync 里, 会因 bShuttingDown 立即返回 false
	if (Server_)
	{
		Server_->stop();
	}

	bRunning.store(false, std::memory_order_release);
	UE_LOG(LogTemp, Log, TEXT("LidarRpcServer: Stopped"));
}


// ─── 安全获取 Lidar 指针 ─────────────────────────────────────────
ILidarComponent* LidarRpcServer::GetLidarSafe()
{
	std::lock_guard<std::mutex> Lock(LidarMutex_);
	if (bShuttingDown)
		return nullptr;
	return Lidar_;
}

bool LidarRpcServer::RunOnGameThreadSync(TFunction<void()> Work, uint32 TimeoutMs)
{
	if (bShuttingDown.load(std::memory_order_acquire))
		return false;

	FEvent* Evt = FPlatformProcess::GetSynchEventFromPool(false);

	auto bTimedOut = std::make_shared<std::atomic<bool>>(false);

	AsyncTask(ENamedThreads::GameThread,
		[Work = MoveTemp(Work), Evt, bTimedOut, this]()
	{
		if (!bShuttingDown.load(std::memory_order_acquire) && !bTimedOut->load())
		{
			Work();
		}
		Evt->Trigger();
	});

	// 关键: 关闭中也需要轮询, 否则会卡在 Wait 里阻塞 server::stop() 等 handler 返回
	const uint32 PollMs = 50;
	uint32 Elapsed = 0;
	bool bSignaled = false;

	while (Elapsed < TimeoutMs)
	{
		const uint32 ThisWait = FMath::Min(PollMs, TimeoutMs - Elapsed);
		if (Evt->Wait(ThisWait))
		{
			bSignaled = true;
			break;
		}
		Elapsed += ThisWait;

		// 关闭信号到来, 立即放弃等待
		if (bShuttingDown.load(std::memory_order_acquire))
		{
			break;
		}
	}

	if (!bSignaled)
	{
		bTimedOut->store(true);
		if (!bShuttingDown.load(std::memory_order_acquire))
		{
			UE_LOG(LogTemp, Warning,
				TEXT("LidarRpcServer: GameThread dispatch timed out (%u ms)"), TimeoutMs);
		}
		// ⚠️ 注意: 这里不能立刻 ReturnSynchEventToPool, 因为 GameThread 回调还会 Trigger 它
		//          交给一个延后任务释放
		AsyncTask(ENamedThreads::GameThread, [Evt]()
		{
			// 此时 GameThread 回调一定已经执行完 (因为我们正在 GameThread)
			FPlatformProcess::ReturnSynchEventToPool(Evt);
		});
		return false;
	}

	FPlatformProcess::ReturnSynchEventToPool(Evt);
	return true;
}

// ─── RPC 方法绑定 ────────────────────────────────────────────────
void LidarRpcServer::BindMethods()
{
	/* ─── ping ─── */
	Server_->bind("ping", [this]() -> bool
	{
		return !bShuttingDown;
	});

	/* ─── getLidarData ─── */
	Server_->bind("getLidarData", [this]() -> std::vector<float>
	{
		ILidarComponent* Lid = GetLidarSafe();
		if (!Lid)
			return {};

		TArray<float> Cloud;
		int32 NumPts = 0;

		bool bOk = RunOnGameThreadSync([Lid, &Cloud, &NumPts]()
		{
			Lid->GetLidarData(Cloud, NumPts);
		});

		if (!bOk)
			return {};

		return std::vector<float>(Cloud.GetData(), Cloud.GetData() + Cloud.Num());
	});

	/* ─── getLidarPose ─── */
	Server_->bind("getLidarPose", [this]() -> std::vector<float>
	{
		ILidarComponent* Lid = GetLidarSafe();
		if (!Lid)
			return { 0, 0, 0, 1, 0, 0, 0 };

		float Pose[7] = { 0, 0, 0, 1, 0, 0, 0 };

		bool bOk = RunOnGameThreadSync([Lid, &Pose]()
		{
			Lid->GetLidarPose(Pose);
		});

		if (!bOk)
			return { 0, 0, 0, 1, 0, 0, 0 };

		return std::vector<float>(Pose, Pose + 7);
	});

	/* ─── getLidarConfig ─── */
	Server_->bind("getLidarConfig", [this]() -> std::vector<float>
	{
		std::lock_guard<std::mutex> Lock(LidarMutex_);
		if (bShuttingDown.load(std::memory_order_acquire) || !Lidar_)
			return {};

		FLidarConfig Cfg = Lidar_->GetLidarConfig();
		return {
			static_cast<float>(Cfg.NumberOfChannels),
			Cfg.VerticalFovUpperDeg,
			Cfg.VerticalFovLowerDeg,
			Cfg.PointsPerSecond,
			Cfg.HorizontalRotationFrequencyHz,
			Cfg.HorizontalFovStartDeg,
			Cfg.HorizontalFovEndDeg,
			Cfg.RangeMeters
		};
	});
}