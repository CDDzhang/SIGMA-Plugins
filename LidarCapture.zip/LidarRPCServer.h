#pragma once

#include "CoreMinimal.h"
#include "ILidarComponent.h"
#include <memory>
#include <atomic>
#include <mutex>
// ─── rpclib 包含前: 先隔离 UE 的宏污染 ───────────────────────
#pragma push_macro("check")
#pragma push_macro("verify")
#undef check
#undef verify

#include "rpc/server.h"

#pragma pop_macro("verify")
#pragma pop_macro("check")
/**
 * MsgPack-RPC 服务端 — 暴露雷达数据给 Python 客户端。
 *
 * 关闭安全设计 (v2):
 * 1. bShuttingDown 原子标志 — handler 入口立即返回空
 * 2. Lidar_ 指针通过 mutex 保护 — Stop() 时置 nullptr
 * 3. RunOnGameThreadSync 检查 bShuttingDown, 关闭后直接返回 false 不再等待
 * 4. Server_->stop() 自身 join 所有工作线程 — 不依赖 sleep
 */
class LidarRpcServer
{
public:
	LidarRpcServer(ILidarComponent* Lidar, uint16_t Port = 41452);
	~LidarRpcServer();

	void Start();
	void Stop();
	bool IsRunning() const { return bRunning.load(std::memory_order_acquire); }

private:
	void BindMethods();

	/** 带超时的 GameThread 同步调用; 关闭中直接返回 false */
	bool RunOnGameThreadSync(TFunction<void()> Work, uint32 TimeoutMs = 1500);

	/** 安全获取 Lidar 指针, 加锁 + 检查关闭标志 */
	ILidarComponent* GetLidarSafe();

	mutable std::mutex             LidarMutex_;
	ILidarComponent*               Lidar_;         // 受 LidarMutex_ 保护
	std::unique_ptr<rpc::server>   Server_;
	uint16_t                       Port_;
	std::atomic<bool>              bRunning { false };
	std::atomic<bool>              bShuttingDown { false };
};