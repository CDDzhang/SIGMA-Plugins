// LidarSensorComponent.cpp

#include "LidarSensorComponent.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"
#include "CollisionQueryParams.h"
#include "Async/ParallelFor.h"
#include "GameFramework/Actor.h"

// ─── 最大单 Tick 射线数上限 ───
static constexpr int32 MAX_POINTS_PER_TICK = 100000;

ULidarSensorComponent::ULidarSensorComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickGroup = TG_PostPhysics;
}

void ULidarSensorComponent::BeginPlay()
{
	Super::BeginPlay();

	CurrentHorizontalAngleDeg = Config.HorizontalFovStartDeg;
	AccumulatedTime = 0.f;
	AccumulateBuffer.Reset();
	AccumulatePointCount = 0;

	// 预分配 (粗估一帧最大点数)
	const float UpdateInterval = 1.f / FMath::Max(Config.UpdateFrequencyHz, 0.1f);
	const int32 EstMaxPoints = FMath::CeilToInt(Config.PointsPerSecond * UpdateInterval);
	AccumulateBuffer.Reserve(EstMaxPoints * 3);
	OutputBuffers[0].Reserve(EstMaxPoints * 3);
	OutputBuffers[1].Reserve(EstMaxPoints * 3);
	ReadyIndex.store(-1, std::memory_order_release);

	CreateLasers();
}

// ─── 根据通道数和垂直 FOV 生成每条 laser 的垂直角 ───
void ULidarSensorComponent::CreateLasers()
{
	const int32 NumCh = FMath::Max(Config.NumberOfChannels, 1);
	LaserVerticalAngles.SetNum(NumCh);

	if (NumCh == 1)
	{
		LaserVerticalAngles[0] = (Config.VerticalFovUpperDeg + Config.VerticalFovLowerDeg) * 0.5f;
		return;
	}

	const float DeltaAngle = (Config.VerticalFovUpperDeg - Config.VerticalFovLowerDeg)
		/ static_cast<float>(NumCh - 1);

	for (int32 i = 0; i < NumCh; ++i)
	{
		LaserVerticalAngles[i] = Config.VerticalFovUpperDeg - DeltaAngle * i;
	}
}

// ─── 收集需要忽略的 Actor (Owner + 所有 Attached/Child) ───
void ULidarSensorComponent::CollectIgnoredActors(TArray<TWeakObjectPtr<AActor>>& OutIgnored) const
{
	AActor* Owner = GetOwner();
	if (!Owner) return;

	OutIgnored.Add(Owner);

	TArray<AActor*> Attached;
	Owner->GetAttachedActors(Attached, /*bResetArray=*/false, /*bRecursivelyIncludeAttachedActors=*/true);
	for (AActor* A : Attached)
	{
		if (A) OutIgnored.Add(A);
	}

	for (AActor* Extra : AdditionalIgnoredActors)
	{
		if (Extra)
		{
			OutIgnored.AddUnique(Extra);
		}
	}
}

// ─── 水平角 FOV 判断 ───
bool ULidarSensorComponent::IsAngleInFov(float Angle, float FovStart, float FovEnd)
{
	Angle    = FMath::Fmod(Angle    + 360.f, 360.f);
	FovStart = FMath::Fmod(FovStart + 360.f, 360.f);
	FovEnd   = FMath::Fmod(FovEnd   + 360.f, 360.f);

	if (FovStart <= FovEnd)
	{
		return Angle >= FovStart && Angle <= FovEnd;
	}
	else
	{
		return Angle >= FovStart || Angle <= FovEnd;
	}
}

// ═══════════════════════════════════════════════════════════
//  核心 Tick: 每帧射线追加到积累缓冲, 达到更新间隔后输出
// ═══════════════════════════════════════════════════════════
void ULidarSensorComponent::TickComponent(float DeltaTime, ELevelTick TickType,
	FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	UWorld* World = GetWorld();
	if (!World) return;

	const int32 NumCh = LaserVerticalAngles.Num();
	if (NumCh <= 0) return;

	/* ─── 1. 计算本 Tick 射线总数 ─── */
	int32 TotalPoints = FMath::RoundHalfFromZero(Config.PointsPerSecond * DeltaTime);
	TotalPoints = FMath::Min(TotalPoints, MAX_POINTS_PER_TICK);

	const int32 PointsPerLaser = FMath::Max(TotalPoints / NumCh, 1);
	const int32 TotalJobs = NumCh * PointsPerLaser;

	/* ─── 2. 水平角步进 ─── */
	const float AngleOfTick = Config.HorizontalRotationFrequencyHz * 360.f * DeltaTime;
	const float AngleStep   = (PointsPerLaser > 1) ? (AngleOfTick / PointsPerLaser) : 0.f;

	const float FovStart = FMath::Fmod(Config.HorizontalFovStartDeg + 360.f, 360.f);
	const float FovEnd   = FMath::Fmod(Config.HorizontalFovEndDeg   + 360.f, 360.f);

	/* ─── 3. 传感器变换 ─── */
	const FTransform SensorTf = GetComponentTransform();
	const FVector    Origin   = SensorTf.GetLocation();
	const float      RangeCm  = Config.RangeMeters * 100.f;

	/* ─── 4. 收集需要忽略的 Actor (用 WeakPtr 防止 ParallelFor 中悬空) ─── */
	TArray<TWeakObjectPtr<AActor>> IgnoredWeak;
	CollectIgnoredActors(IgnoredWeak);

	// 提前展开成裸指针数组, 仅 GameThread 取一次 — ParallelFor 内只读
	TArray<AActor*> IgnoredRaw;
	IgnoredRaw.Reserve(IgnoredWeak.Num());
	for (auto& W : IgnoredWeak)
	{
		if (AActor* A = W.Get())
		{
			IgnoredRaw.Add(A);
		}
	}

	/* ─── 5. 本 Tick 射线 (临时 buffer, FLT_MAX 标记无效) ─── */
	TArray<float> TickRaw;
	TickRaw.SetNumUninitialized(TotalJobs * 3);
	for (int32 i = 0; i < TickRaw.Num(); ++i)
	{
		TickRaw[i] = FLT_MAX;
	}
	
	/* ─── 6. ParallelFor 并行射线检测 ─── */
	ParallelFor(TotalJobs, [&](int32 Idx)
	{
		const int32 LaserIdx = Idx / PointsPerLaser;
		const int32 RayIdx   = Idx % PointsPerLaser;

		const float VertAngle = LaserVerticalAngles[LaserIdx];
		const float HorizAngle = FMath::Fmod(
			CurrentHorizontalAngleDeg + AngleStep * RayIdx, 360.f);

		if (!IsAngleInFov(HorizAngle, FovStart, FovEnd))
		{
			return;  // bValid 保持 false, 后面就不画
		}

		const FRotator RayRot(VertAngle, HorizAngle, 0.f);
		FVector WorldDir = SensorTf.TransformVectorNoScale(RayRot.Vector());
		WorldDir.Normalize();

		const FVector End = Origin + WorldDir * RangeCm;

		FHitResult Hit;
		FCollisionQueryParams Params;
		Params.bReturnPhysicalMaterial = false;
		Params.bTraceComplex = false;

		for (AActor* Ignored : IgnoredRaw)
		{
			Params.AddIgnoredActor(Ignored);
		}

		const bool bHit = World->LineTraceSingleByChannel(
			Hit, Origin, End, Config.TraceChannel, Params);

		if (bHit)
		{
			FVector LocalHit = SensorTf.InverseTransformPosition(Hit.ImpactPoint);
			LocalHit /= 100.f;  // cm → m

			TickRaw[Idx * 3 + 0] = LocalHit.X;
			TickRaw[Idx * 3 + 1] = LocalHit.Y;
			TickRaw[Idx * 3 + 2] = LocalHit.Z;
		}
	});

	/* ─── 7. 筛除无效点, 追加到积累缓冲, 顺便画 Debug ─── */
	for (int32 i = 0; i < TickRaw.Num(); i += 3)
	{
		if (TickRaw[i] != FLT_MAX)
		{
			const float LX = TickRaw[i];
			const float LY = TickRaw[i + 1];
			const float LZ = TickRaw[i + 2];

			AccumulateBuffer.Add(LX);
			AccumulateBuffer.Add(LY);
			AccumulateBuffer.Add(LZ);
			++AccumulatePointCount;

			if (bDrawDebugPoints)
			{
				// 局部 (米) → 世界 (cm)
				const FVector WorldHit = SensorTf.TransformPosition(
					FVector(LX, LY, LZ) * 100.f);
				DrawDebugPoint(World, WorldHit, DebugPointSize, DebugPointColor,
					/*bPersistent*/ false, DebugPointLifeTime);
			}
		}
	}

	/* ─── 8. 推进水平角 ─── */
	CurrentHorizontalAngleDeg = FMath::Fmod(CurrentHorizontalAngleDeg + AngleOfTick, 360.f);

	/* ─── 9. 检查是否到达更新间隔 ─── */
	AccumulatedTime += DeltaTime;
	const float UpdateInterval = 1.f / FMath::Max(Config.UpdateFrequencyHz, 0.1f);

	if (AccumulatedTime >= UpdateInterval)
	{
		// 写到非 ready 的那个 buffer
		const int32 CurReady = ReadyIndex.load(std::memory_order_acquire);
		const int32 WriteIdx = (CurReady == 0) ? 1 : 0;  // -1 时也写 0

		OutputBuffers[WriteIdx]      = MoveTemp(AccumulateBuffer);
		OutputPointCounts[WriteIdx]  = AccumulatePointCount;

		// 原子切换 ready 索引 — 这一刻起读端会看到新帧
		ReadyIndex.store(WriteIdx, std::memory_order_release);

		// 重置积累状态
		AccumulateBuffer.Reset();
		AccumulateBuffer.Reserve(OutputBuffers[WriteIdx].Num());
		AccumulatePointCount = 0;
		AccumulatedTime      = 0.f;

		UE_LOG(LogTemp, Verbose, TEXT("LidarSensor: Frame ready — %d points (buf %d)"),
			OutputPointCounts[WriteIdx], WriteIdx);
	}

	/* ─── 10. 安全上限检查 ─── */
	if (AccumulateBuffer.Num() > MAX_ACCUMULATE_FLOATS)
	{
		UE_LOG(LogTemp, Warning,
			TEXT("LidarSensor: AccumulateBuffer exceeded %d floats, dropping frame. "
				 "Check UpdateFrequencyHz vs PointsPerSecond."),
			MAX_ACCUMULATE_FLOATS);
		AccumulateBuffer.Reset();
		AccumulatePointCount = 0;
		AccumulatedTime = 0.f;
	}
}

// ═══════════════════════════════════════════════════════════
//  ILidarComponent 接口实现
// ═══════════════════════════════════════════════════════════
void ULidarSensorComponent::GetLidarData(TArray<float>& OutPointCloud, int32& OutNumPoints)
{
	const int32 Idx = ReadyIndex.load(std::memory_order_acquire);
	if (Idx < 0)
	{
		// 还没生成过任何完整帧
		OutPointCloud.Reset();
		OutNumPoints = 0;
		return;
	}

	// 这里仍然是拷贝 — 因为 GameThread 可能在下个 Tick 把这个 buffer 当 WriteIdx 重写。
	// 真正零拷贝需要三缓冲, 但通常 12MB 拷贝在 GameThread 上 1ms 以内, 双缓冲已足够。
	OutPointCloud = OutputBuffers[Idx];
	OutNumPoints  = OutputPointCounts[Idx];
}



void ULidarSensorComponent::GetLidarPose(float OutPose[7])
{
	const FTransform Tf = GetComponentTransform();
	const FVector Pos = Tf.GetLocation() / 100.f;
	const FQuat   Rot = Tf.GetRotation();

	OutPose[0] = Pos.X;
	OutPose[1] = Pos.Y;
	OutPose[2] = Pos.Z;
	OutPose[3] = Rot.W;
	OutPose[4] = Rot.X;
	OutPose[5] = Rot.Y;
	OutPose[6] = Rot.Z;
}