#pragma once

#include <atomic>
#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "ILidarComponent.h"
#include "LidarSensorComponent.generated.h"

/**
 * 旋转雷达组件。
 *
 * 每个 Tick 做 ParallelFor 射线检测, 结果追加到积累缓冲;
 * 累计时间达到 1/UpdateFrequencyHz 后, 将积累的完整帧
 * 输出到 OutputCloud, 然后清空缓冲开始下一帧。
 * 与 AirSim 的 FrequencyLimiter 行为一致。
 *
 * 自动忽略 Owner Actor 及其所有子 Actor 的碰撞。
 */
UCLASS(ClassGroup=(Sensor), meta=(BlueprintSpawnableComponent))
class OMNIFISHEYES_API ULidarSensorComponent
	: public USceneComponent 
	, public ILidarComponent
{
	GENERATED_BODY()

public:
	ULidarSensorComponent();

	/* ─── 蓝图可编辑参数 ─── */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	FLidarConfig Config;

	/** 额外需要忽略的 Actor 列表 (除 Owner 自身外) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar")
	TArray<AActor*> AdditionalIgnoredActors;

	/** 是否绘制命中点。 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar|Debug")
	bool bDrawDebugPoints = false;

	/** 命中点的大小(像素)。 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar|Debug",
		meta = (EditCondition = "bDrawDebugPoints", ClampMin = "1.0", ClampMax = "20.0"))
	float DebugPointSize = 4.f;

	/** 命中点颜色。 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar|Debug",
		meta = (EditCondition = "bDrawDebugPoints"))
	FColor DebugPointColor = FColor::Green;
	
	/** 点的持续时间(秒)。0 = 只画一帧。*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lidar|Debug",
		meta = (EditCondition = "bDrawDebugPoints", ClampMin = "0.0", ClampMax = "1.0"))
	float DebugPointLifeTime = 0.1f;

	
	
	/* ─── ILidarComponent 接口 ─── */
	virtual void GetLidarData(TArray<float>& OutPointCloud, int32& OutNumPoints) override;
	virtual void GetLidarPose(float OutPose[7]) override;
	virtual FLidarConfig GetLidarConfig() const override { return Config; }

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType,
		FActorComponentTickFunction* ThisTickFunction) override;

private:
	/** 初始化垂直角度表 */
	void CreateLasers();

	/** 收集 Owner 及其所有 ChildActor / AttachedActor 用于忽略 */
	void CollectIgnoredActors(TArray<TWeakObjectPtr<AActor>>& OutIgnored) const;
	// void CollectIgnoredActors(TArray<AActor*>& OutIgnored) const;
	
	/** 判断水平角是否在 FOV 扇区内 (处理跨 0° 的情况) */
	static bool IsAngleInFov(float Angle, float FovStart, float FovEnd);

	/* ─── 运行时状态 ─── */
	TArray<float> LaserVerticalAngles;
	float CurrentHorizontalAngleDeg = 0.f;

	/** 积累缓冲: 跨多个 Tick 收集射线结果 (仅 GameThread 访问) */
	TArray<float> AccumulateBuffer;
	int32         AccumulatePointCount = 0;
	float         AccumulatedTime = 0.f;
	
	/** ─── 双缓冲输出 ───
		 *  Tick 写一个 buffer, 读端读另一个 buffer, ReadyIndex 原子切换。
		 *  - GameThread Tick 写: OutputBuffers[1 - ReadyIndex]
		 *  - 任意线程读: 通过 GetLidarData() (会被 dispatch 回 GameThread, 读 ReadyIndex)
		 *  即使读发生在 Tick 中途, 读到的也是上一帧的完整数据。
		 */
	TArray<float>     OutputBuffers[2];
	int32             OutputPointCounts[2] = { 0, 0 };
	std::atomic<int32> ReadyIndex { -1 };  // -1 表示还没有任何成品帧
	/** 安全上限: 防止 AccumulateBuffer 无界增长 */
	static constexpr int32 MAX_ACCUMULATE_FLOATS = 3 * 1000000;  // 100万点 = 12MB
};