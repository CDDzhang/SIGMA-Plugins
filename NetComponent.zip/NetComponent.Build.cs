using UnrealBuildTool;

public class NetComponent : ModuleRules
{
	public NetComponent(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] {
			"Core", "CoreUObject", "Engine",
			"Sockets", "Networking"
		});

		PrivateDependencyModuleNames.AddRange(new string[] {});
	}
}