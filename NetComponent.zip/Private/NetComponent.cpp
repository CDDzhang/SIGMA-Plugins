// Private/NetComponent.cpp
#include "NetComponent.h"

IMPLEMENT_MODULE(FNetComponentModule, NetComponent)