#include "UavStateReceiverComponent.h"

#include "Sockets.h"
#include "SocketSubsystem.h"
#include "Common/UdpSocketBuilder.h"
#include "HAL/RunnableThread.h"
#include "HAL/Runnable.h"

DEFINE_LOG_CATEGORY_STATIC(LogUavRx, Log, All);

namespace
{
    constexpr uint32 kMagic = 0x55414531u; // "UAE1"

    /** ENU(m) → UE(cm). 翻 Y, 米转厘米. */
    FORCEINLINE FVector EnuToUePosition(const float Ros[3], float Scale)
    {
        return FVector( Ros[0] * Scale,    //  East  →  +X
                       -Ros[1] * Scale,    //  North →  -Y (左/右手切换)
                        Ros[2] * Scale);   //  Up    →  +Z
    }

    /** ENU 四元数 → UE 四元数. UE 的 FQuat 是 (X, Y, Z, W). */
    FORCEINLINE FQuat EnuToUeQuat(const float Q[4])
    {
        // ROS pkt: qx qy qz qw
        // 翻 Y: qx' = -qx, qy' = qy, qz' = -qz, qw' = qw
        return FQuat(-Q[0], Q[1], -Q[2], Q[3]);
    }
}


// ─────────────────── 网络线程 ───────────────────
class FUavReceiverWorker : public FRunnable
{
public:
    FUavReceiverWorker(UUavStateReceiverComponent* InOwner, FSocket* InSocket)
        : Owner(InOwner), Socket(InSocket) {}

    virtual bool Init() override { return Socket != nullptr; }

    virtual uint32 Run() override
    {
        TArray<uint8> Buffer;
        Buffer.SetNumUninitialized(1024);

        TSharedRef<FInternetAddr> From =
            ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateInternetAddr();

        while (!bStopping)
        {
            // 阻塞读, 1s 超时, 由 socket 的 receive timeout 控制
            int32 BytesRead = 0;
            bool bOK = Socket->RecvFrom(Buffer.GetData(), Buffer.Num(),
                                        BytesRead, *From);
            if (!bOK || BytesRead < (int32)sizeof(FUavStatePacket))
            {
                continue;
            }

            FUavStatePacket Pkt;
            FMemory::Memcpy(&Pkt, Buffer.GetData(), sizeof(Pkt));

            if (Pkt.Magic != kMagic) continue;

            if (Owner->FilterUavId != 0 &&
                (int32)Pkt.UavId != Owner->FilterUavId) continue;

            FLatestState NewState;
            NewState.RosPos  = FVector(Pkt.Pos[0], Pkt.Pos[1], Pkt.Pos[2]);
            NewState.RosQuat = FQuat(Pkt.Quat[0], Pkt.Quat[1], Pkt.Quat[2], Pkt.Quat[3]);
            NewState.Seq    = Pkt.Seq;
            NewState.bValid = true;

            {
                FScopeLock Lock(&Owner->StateMutex);
                Owner->LatestState = NewState;
            }
        }
        return 0;
    }

    virtual void Stop() override { bStopping = true; }

private:
    UUavStateReceiverComponent* Owner = nullptr;
    FSocket* Socket = nullptr;
    FThreadSafeBool bStopping = false;
};


// ─────────────────── Component ───────────────────
UUavStateReceiverComponent::UUavStateReceiverComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
}

void UUavStateReceiverComponent::BeginPlay()
{
    Super::BeginPlay();

    // 存初始位姿 —— UE 中的 "ROS 原点"
    if (AActor* Owner = GetOwner())
    {
        InitialActorLocation = Owner->GetActorLocation();
        InitialActorRotation = Owner->GetActorQuat();
    }

    // 建 UDP socket, bind 到 ListenPort, 所有网卡
    FIPv4Endpoint Endpoint(FIPv4Address::Any, (uint16)ListenPort);
    Socket = FUdpSocketBuilder(TEXT("UavRxSocket"))
    .AsReusable()
    .BoundToEndpoint(Endpoint)
    .WithReceiveBufferSize(1 << 16);

    if (!Socket)
    {
        UE_LOG(LogUavRx, Error, TEXT("Failed to bind UDP port %d"), ListenPort);
        return;
    }

    Worker = new FUavReceiverWorker(this, Socket);
    Thread = FRunnableThread::Create(Worker, TEXT("UavRxThread"));

    UE_LOG(LogUavRx, Log, TEXT("UAV state receiver listening on UDP %d"), ListenPort);
}

void UUavStateReceiverComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    if (Thread)
    {
        Worker->Stop();
        if (Socket) Socket->Close();  // 让阻塞的 RecvFrom 返回
        Thread->WaitForCompletion();
        delete Thread;  Thread = nullptr;
        delete Worker;  Worker = nullptr;
    }
    if (Socket)
    {
        ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->DestroySocket(Socket);
        Socket = nullptr;
    }
    Super::EndPlay(EndPlayReason);
}

void UUavStateReceiverComponent::TickComponent(float DeltaTime, ELevelTick TickType,
    FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    FLatestState Snap;
    {
        FScopeLock Lock(&StateMutex);
        Snap = LatestState;
    }
    if (!Snap.bValid || !bApplyToActor) return;

    AActor* OwnerActor = GetOwner();
    if (!OwnerActor) return;

    // ── B 模式: 第一帧锁定 ROS 参考点 ──
    if (!bRefCaptured)
    {
        RefRosPos    = Snap.RosPos;
        RefRosQuat   = Snap.RosQuat;
        bRefCaptured = true;

        UE_LOG(LogUavRx, Log,
            TEXT("Reference captured: ros_pos=(%.2f,%.2f,%.2f) m"),
            RefRosPos.X, RefRosPos.Y, RefRosPos.Z);
    }

    // ── ROS 增量 (ENU, m) ──
    // 位置增量: 当前 - 参考, 仍在 ROS 系下
    const FVector DeltaRosPos = Snap.RosPos - RefRosPos;
    // 姿态增量: 当前 = ΔQ * 参考  =>  ΔQ = 当前 * 参考^-1
    const FQuat   DeltaRosQuat = Snap.RosQuat * RefRosQuat.Inverse();

    // ── ENU → UE 转换 ──
    const float Ros[3] = {
        (float)DeltaRosPos.X, (float)DeltaRosPos.Y, (float)DeltaRosPos.Z };
    const FVector DeltaOffsetUE = EnuToUePosition(Ros, MetersToUU);

    const float Q[4] = {
        (float)DeltaRosQuat.X, (float)DeltaRosQuat.Y,
        (float)DeltaRosQuat.Z, (float)DeltaRosQuat.W };
    const FQuat   DeltaRotUE = EnuToUeQuat(Q);

    // ── 叠到 Actor 初始位姿 ──
    const FVector WorldLocation = InitialActorLocation +
                                  InitialActorRotation.RotateVector(DeltaOffsetUE);
    const FQuat   WorldRotation = InitialActorRotation * DeltaRotUE;

    OwnerActor->SetActorLocationAndRotation(WorldLocation, WorldRotation,
        /*bSweep*/ false, nullptr, ETeleportType::TeleportPhysics);

    if (bVerboseLog)
    {
        UE_LOG(LogUavRx, Log,
            TEXT("seq=%u dRos=(%.2f,%.2f,%.2f)m -> world=(%.0f,%.0f,%.0f)cm"),
            Snap.Seq, DeltaRosPos.X, DeltaRosPos.Y, DeltaRosPos.Z,
            WorldLocation.X, WorldLocation.Y, WorldLocation.Z);
    }
}