// Public/NetComponent.h
#pragma once
#include "Modules/ModuleManager.h"

class FNetComponentModule : public IModuleInterface {};