#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HAL/Runnable.h"
#include "UavStateReceiverComponent.generated.h"

class FSocket;
class FRunnableThread;
class FUavReceiverWorker;

#pragma pack(push, 1)
struct FUavStatePacket
{
    uint32  Magic;       // 0x55414531
    uint32  Seq;
    double  Timestamp;
    uint32  UavId;
    float   Pos[3];      // ENU, m
    float   Quat[4];     // qx qy qz qw
    float   LinVel[3];
    float   AngVel[3];
};
#pragma pack(pop)
static_assert(sizeof(FUavStatePacket) == 72, "Packet must be 72 bytes");

/** 最新一帧 + lock-free 标记 */
struct FLatestState
{
    FVector  RosPos       = FVector::ZeroVector;
    FQuat    RosQuat      = FQuat::Identity;
    uint32   Seq          = 0;
    bool     bValid       = false;
};


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class NETCOMPONENT_API UUavStateReceiverComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UUavStateReceiverComponent();

    /** 本机监听端口,跟 ROS 端 bridge 的 ue_port 一致 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="UAV|Network")
    int32 ListenPort = 41450;

    /** 只接受这个 uav_id 的包(0 = 任意) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="UAV|Network")
    int32 FilterUavId = 1;

    /** ROS 端 X/Y/Z 单位是米, UE 是 cm */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="UAV|Transform")
    float MetersToUU = 100.f;

    /** 关掉的话只接收不动 Actor (调试用) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="UAV|Transform")
    bool bApplyToActor = true;

    /** 是否打印接收日志 */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="UAV|Debug")
    bool bVerboseLog = false;
    
    /** 重新锚定原点 */
    UFUNCTION(BlueprintCallable, Category="UAV|Network")
    void ResetReference() { bRefCaptured = false; }

protected:
    virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType,
        FActorComponentTickFunction* ThisTickFunction) override;

private:
    // 起飞时存的 Actor 初始位姿,作为 ROS 原点在 UE 中的位姿
    FVector  InitialActorLocation = FVector::ZeroVector;
    FQuat    InitialActorRotation = FQuat::Identity;

    // 网络线程
    FSocket*           Socket  = nullptr;
    FRunnableThread*   Thread  = nullptr;
    FUavReceiverWorker* Worker = nullptr;

    // 工作线程写, 主线程读, 用关键段保护
    FCriticalSection   StateMutex;
    FLatestState       LatestState;

    // 第一帧 UDP 时的 ROS pose, 作为 "ROS 原点" 锚定到 UE InitialActor 上
    bool     bRefCaptured       = false;
    FVector  RefRosPos          = FVector::ZeroVector;
    FQuat    RefRosQuat         = FQuat::Identity;
    
    friend class FUavReceiverWorker;
};